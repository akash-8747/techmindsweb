import { useEffect, useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import type { NotificationLogEntry, NotificationType } from '@/types/database';
import { Bell, Mail, Clock, AlertCircle, FileText, Check, X, RefreshCw } from 'lucide-react';

const typeConfig: Record<NotificationType, { label: string; icon: typeof Bell; color: string }> = {
  welcome: { label: 'Welcome', icon: Mail, color: 'bg-blue-50 text-blue-700' },
  family_invitation: { label: 'Family Invitation', icon: Mail, color: 'bg-teal-50 text-teal-700' },
  inactivity_15: { label: '15-Day Reminder', icon: Clock, color: 'bg-amber-50 text-amber-700' },
  inactivity_30: { label: '30-Day Alert', icon: AlertCircle, color: 'bg-red-50 text-red-700' },
  monthly_report: { label: 'Monthly Report', icon: FileText, color: 'bg-purple-50 text-purple-700' },
  additional_support: { label: 'Support Alert', icon: AlertCircle, color: 'bg-orange-50 text-orange-700' },
  follow_up: { label: 'Follow-up', icon: Bell, color: 'bg-slate-100 text-slate-700' },
  test: { label: 'Test', icon: Mail, color: 'bg-slate-100 text-slate-600' },
};

const statusConfig: Record<string, { label: string; icon: typeof Check; color: string }> = {
  sent: { label: 'Sent', icon: Check, color: 'bg-green-50 text-green-700' },
  failed: { label: 'Failed', icon: X, color: 'bg-red-50 text-red-700' },
  pending: { label: 'Pending', icon: Clock, color: 'bg-amber-50 text-amber-700' },
  retrying: { label: 'Retrying', icon: RefreshCw, color: 'bg-blue-50 text-blue-700' },
};

export function NotificationHistoryView() {
  const { profile } = useAuth();
  const [logs, setLogs] = useState<NotificationLogEntry[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    if (!profile) return;
    const { data } = await supabase
      .from('notification_log')
      .select('*')
      .eq('user_id', profile.id)
      .order('created_at', { ascending: false })
      .limit(50);
    setLogs((data as NotificationLogEntry[]) || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, [profile]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Notification History</h2>
        <p className="text-slate-500 mt-1">View the delivery status of your email notifications.</p>
      </div>

      {logs.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <Bell className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500">No notifications have been sent yet.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {logs.map((log) => {
            const tc = typeConfig[log.notification_type] || typeConfig.test;
            const sc = statusConfig[log.status] || statusConfig.pending;
            const TypeIcon = tc.icon;
            const StatusIcon = sc.icon;
            return (
              <div key={log.id} className="bg-white rounded-xl border border-slate-200 p-4 flex items-start gap-4">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${tc.color}`}>
                  <TypeIcon className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="text-sm font-medium text-slate-900">{log.subject || tc.label}</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full flex items-center gap-1 ${sc.color}`}>
                      <StatusIcon className="w-3 h-3" />
                      {sc.label}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">
                    To: {log.recipient_email} · {new Date(log.created_at).toLocaleString()}
                  </p>
                  {log.error_message && (
                    <p className="text-xs text-red-500 mt-1">Error: {log.error_message}</p>
                  )}
                  {log.provider_message_id && (
                    <p className="text-xs text-slate-400 mt-0.5">Message ID: {log.provider_message_id}</p>
                  )}
                  {log.retry_count > 0 && (
                    <p className="text-xs text-amber-500 mt-0.5">Retries: {log.retry_count}</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
