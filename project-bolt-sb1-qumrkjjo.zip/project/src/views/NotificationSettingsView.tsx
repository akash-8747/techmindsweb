import { useEffect, useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import type { NotificationPreferences } from '@/types/database';
import { Mail, Bell, FileText, Clock, Users, GraduationCap, AlertCircle, Check, Loader2, Send } from 'lucide-react';

export function NotificationSettingsView() {
  const { profile } = useAuth();
  const [prefs, setPrefs] = useState<NotificationPreferences | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [testEmail, setTestEmail] = useState('');
  const [testStatus, setTestStatus] = useState<{ type: 'idle' | 'sending' | 'success' | 'error'; message: string }>({
    type: 'idle', message: '',
  });

  const load = async () => {
    if (!profile) return;
    const { data } = await supabase
      .from('notification_preferences')
      .select('*')
      .eq('user_id', profile.id)
      .maybeSingle();
    setPrefs(data as NotificationPreferences | null);
    setLoading(false);
  };

  useEffect(() => { load(); }, [profile]);

  const handleUpdate = async (field: keyof NotificationPreferences, value: boolean) => {
    if (!profile || !prefs) return;
    setSaving(true);
    setSaved(false);
    const updated = { ...prefs, [field]: value };
    setPrefs(updated);
    const { error } = await supabase
      .from('notification_preferences')
      .update({ [field]: value, updated_at: new Date().toISOString() })
      .eq('user_id', profile.id);
    setSaving(false);
    if (!error) {
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    }
  };

  const handleTestEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    setTestStatus({ type: 'sending', message: 'Sending test email...' });

    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-email`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({
          type: 'test',
          recipient_email: testEmail || profile.email,
          template_data: {
            recipientName: profile.full_name || profile.email,
          },
        }),
      });

      if (!response.ok) {
        const body = await response.json().catch(() => ({}));
        setTestStatus({ type: 'error', message: body.error || `Failed to send (${response.status})` });
      } else {
        const body = await response.json();
        setTestStatus({ type: 'success', message: `Test email sent successfully! Message ID: ${body.message_id || 'N/A'}` });
      }
    } catch {
      setTestStatus({ type: 'error', message: 'Could not reach the email service. Check your connection.' });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
      </div>
    );
  }

  const toggles: { key: keyof NotificationPreferences; label: string; desc: string; icon: typeof Mail }[] = [
    { key: 'email_enabled', label: 'Email Notifications', desc: 'Master switch for all email notifications', icon: Mail },
    { key: 'monthly_report_enabled', label: 'Monthly Progress Reports', desc: 'Receive a monthly summary of your progress', icon: FileText },
    { key: 'learning_reminder_enabled', label: 'Learning Reminders', desc: 'Get reminders when you have been inactive', icon: Clock },
    { key: 'parent_notifications_enabled', label: 'Parent/Guardian Notifications', desc: 'Allow parents to receive your progress updates', icon: Users },
    { key: 'mentor_notifications_enabled', label: 'Mentor Notifications', desc: 'Allow mentors to receive your progress updates', icon: GraduationCap },
    { key: 'support_alerts_enabled', label: 'Additional Support Alerts', desc: 'Receive alerts when assessments indicate extra help is needed', icon: AlertCircle },
  ];

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Notification Settings</h2>
        <p className="text-slate-500 mt-1">Control which email notifications you receive.</p>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <div className="flex items-center justify-between mb-5">
          <h3 className="font-semibold text-slate-900 flex items-center gap-2">
            <Bell className="w-5 h-5 text-blue-600" />
            Email Preferences
          </h3>
          <div className="flex items-center gap-2 text-sm">
            {saving && <span className="text-slate-400 flex items-center gap-1"><Loader2 className="w-3 h-3 animate-spin" /> Saving...</span>}
            {saved && <span className="text-green-600 flex items-center gap-1"><Check className="w-4 h-4" /> Saved</span>}
          </div>
        </div>

        <div className="space-y-1">
          {toggles.map(({ key, label, desc, icon: Icon }) => {
            const enabled = prefs?.[key] ?? false;
            const isMaster = key === 'email_enabled';
            const masterOff = prefs && !prefs.email_enabled && !isMaster;
            return (
              <div className={`flex items-center justify-between py-4 px-4 rounded-lg ${isMaster ? 'bg-slate-50' : ''} ${masterOff ? 'opacity-50' : ''}`}>
                <div className="flex items-start gap-3 flex-1">
                  <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${
                    enabled ? 'bg-blue-50 text-blue-600' : 'bg-slate-100 text-slate-400'
                  }`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-900">{label}</p>
                    <p className="text-xs text-slate-400 mt-0.5">{desc}</p>
                  </div>
                </div>
                <button
                  onClick={() => handleUpdate(key, !enabled)}
                  disabled={masterOff as boolean}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors flex-shrink-0 ${
                    enabled ? 'bg-blue-600' : 'bg-slate-300'
                  } ${masterOff ? 'cursor-not-allowed' : 'cursor-pointer'}`}
                >
                  <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${enabled ? 'translate-x-6' : 'translate-x-1'}`} />
                </button>
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <h3 className="font-semibold text-slate-900 flex items-center gap-2 mb-4">
          <Send className="w-5 h-5 text-blue-600" />
          Send Test Email
        </h3>
        <p className="text-sm text-slate-500 mb-4">
          Verify your Gmail integration is working by sending a test email to yourself or another recipient.
        </p>
        <form onSubmit={handleTestEmail} className="flex gap-3">
          <input
            type="email"
            value={testEmail}
            onChange={(e) => setTestEmail(e.target.value)}
            placeholder={profile?.email || 'recipient@example.com'}
            className="flex-1 px-4 py-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none text-slate-900"
          />
          <button
            type="submit"
            disabled={testStatus.type === 'sending'}
            className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-lg text-sm font-medium disabled:opacity-60 flex items-center gap-2"
          >
            {testStatus.type === 'sending' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            Send Test
          </button>
        </form>
        {testStatus.type !== 'idle' && testStatus.type !== 'sending' && (
          <div className={`mt-4 px-4 py-3 rounded-lg text-sm ${
            testStatus.type === 'success' ? 'bg-green-50 border border-green-200 text-green-700' : 'bg-red-50 border border-red-200 text-red-700'
          }`}>
            {testStatus.message}
          </div>
        )}
        {testStatus.type === 'sending' && (
          <div className="mt-4 px-4 py-3 rounded-lg text-sm bg-blue-50 border border-blue-200 text-blue-700">
            {testStatus.message}
          </div>
        )}
      </div>
    </div>
  );
}
