import { useEffect, useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import type { Assessment } from '@/types/database';
import { ClipboardCheck, Plus, AlertCircle, X } from 'lucide-react';

export function AssessmentsView() {
  const { profile } = useAuth();
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState('');
  const [score, setScore] = useState('');
  const [maxScore, setMaxScore] = useState('100');
  const [needsSupport, setNeedsSupport] = useState(false);
  const [supportNotes, setSupportNotes] = useState('');
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    if (!profile) return;
    const { data } = await supabase
      .from('assessments')
      .select('*')
      .eq('student_id', profile.id)
      .order('completed_at', { ascending: false });
    setAssessments((data as Assessment[]) || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, [profile]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    setError(null);

    const scoreNum = score ? parseInt(score) : null;
    const maxNum = parseInt(maxScore) || 100;

    const { error: err } = await supabase.from('assessments').insert({
      student_id: profile.id,
      title,
      score: scoreNum,
      max_score: maxNum,
      needs_additional_support: needsSupport,
      support_notes: supportNotes,
    });

    if (err) { setError(err.message); return; }

    setTitle(''); setScore(''); setMaxScore('100'); setNeedsSupport(false); setSupportNotes('');
    setShowForm(false);
    load();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Assessments</h2>
          <p className="text-slate-500 mt-1">Track your career assessment results.</p>
        </div>
        <button onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-lg text-sm font-medium">
          <Plus className="w-4 h-4" /> New Assessment
        </button>
      </div>

      {error && <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg px-4 py-3">{error}</div>}

      {showForm && (
        <form onSubmit={handleCreate} className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-slate-900">New Assessment</h3>
            <button type="button" onClick={() => setShowForm(false)} className="p-1 rounded hover:bg-slate-100"><X className="w-5 h-5 text-slate-400" /></button>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Title</label>
            <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} required
              className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none text-slate-900" placeholder="Career Aptitude Test" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Score</label>
              <input type="number" value={score} onChange={(e) => setScore(e.target.value)}
                className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none text-slate-900" placeholder="75" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Max Score</label>
              <input type="number" value={maxScore} onChange={(e) => setMaxScore(e.target.value)}
                className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none text-slate-900" placeholder="100" />
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button type="button" onClick={() => setNeedsSupport(!needsSupport)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${needsSupport ? 'bg-orange-100 text-orange-700 border border-orange-300' : 'bg-slate-100 text-slate-600'}`}>
              <AlertCircle className="w-4 h-4" />
              {needsSupport ? 'Marked as needing support' : 'Mark as needing additional support'}
            </button>
          </div>
          {needsSupport && (
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Support Notes</label>
              <textarea value={supportNotes} onChange={(e) => setSupportNotes(e.target.value)} rows={3}
                className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none text-slate-900" placeholder="Areas where additional help may be needed..." />
            </div>
          )}
          <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-lg text-sm font-medium">Save Assessment</button>
        </form>
      )}

      {assessments.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <ClipboardCheck className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500">No assessments yet. Create your first assessment to track your progress!</p>
        </div>
      ) : (
        <div className="space-y-3">
          {assessments.map((a) => (
            <div key={a.id} className="bg-white rounded-xl border border-slate-200 p-5 flex items-center justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <p className="font-medium text-slate-900">{a.title}</p>
                  {a.needs_additional_support && (
                    <span className="text-xs px-2 py-0.5 rounded-full bg-orange-50 text-orange-700 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" /> Needs Support
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400 mt-1">{new Date(a.completed_at).toLocaleDateString()}</p>
                {a.support_notes && <p className="text-sm text-slate-500 mt-2">{a.support_notes}</p>}
              </div>
              <div className="text-right ml-4">
                <p className="text-2xl font-bold text-slate-900">{a.score !== null ? a.score : '—'}</p>
                <p className="text-xs text-slate-400">/ {a.max_score}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
