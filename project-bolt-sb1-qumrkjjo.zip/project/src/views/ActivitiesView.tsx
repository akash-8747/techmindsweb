import { useEffect, useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import type { Activity } from '@/types/database';
import { Plus, FileText, X, Calendar } from 'lucide-react';

export function ActivitiesView() {
  const { profile } = useAuth();
  const [activities, setActivities] = useState<Activity[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [description, setDescription] = useState('');
  const [activityType, setActivityType] = useState('learning');
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    if (!profile) return;
    const { data } = await supabase
      .from('activities')
      .select('*')
      .eq('student_id', profile.id)
      .order('activity_date', { ascending: false });
    setActivities((data as Activity[]) || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, [profile]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    setError(null);
    const { error: err } = await supabase.from('activities').insert({
      student_id: profile.id,
      description,
      activity_type: activityType,
    });
    if (err) { setError(err.message); return; }
    setDescription(''); setActivityType('learning'); setShowForm(false);
    load();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
      </div>
    );
  }

  const typeColors: Record<string, string> = {
    learning: 'bg-blue-50 text-blue-700',
    assessment: 'bg-purple-50 text-purple-700',
    practice: 'bg-teal-50 text-teal-700',
    reading: 'bg-orange-50 text-orange-700',
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Learning Activities</h2>
          <p className="text-slate-500 mt-1">Log your learning activities to track progress.</p>
        </div>
        <button onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-lg text-sm font-medium">
          <Plus className="w-4 h-4" /> Log Activity
        </button>
      </div>

      {error && <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg px-4 py-3">{error}</div>}

      {showForm && (
        <form onSubmit={handleCreate} className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-slate-900">Log New Activity</h3>
            <button type="button" onClick={() => setShowForm(false)} className="p-1 rounded hover:bg-slate-100"><X className="w-5 h-5 text-slate-400" /></button>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Description</label>
            <input type="text" value={description} onChange={(e) => setDescription(e.target.value)} required
              className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none text-slate-900" placeholder="Completed Python basics module" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Activity Type</label>
            <div className="grid grid-cols-4 gap-2">
              {['learning', 'assessment', 'practice', 'reading'].map((t) => (
                <button key={t} type="button" onClick={() => setActivityType(t)}
                  className={`py-2.5 px-3 rounded-lg text-sm font-medium capitalize transition-all ${activityType === t ? 'bg-blue-600 text-white shadow-md' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>
                  {t}
                </button>
              ))}
            </div>
          </div>
          <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-lg text-sm font-medium">Save Activity</button>
        </form>
      )}

      {activities.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500">No activities logged yet. Log your first learning activity!</p>
        </div>
      ) : (
        <div className="space-y-3">
          {activities.map((act) => (
            <div key={act.id} className="bg-white rounded-xl border border-slate-200 p-4 flex items-center gap-4">
              <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center flex-shrink-0">
                <Calendar className="w-5 h-5 text-slate-400" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-slate-900">{act.description}</p>
                <p className="text-xs text-slate-400">{new Date(act.activity_date).toLocaleDateString()}</p>
              </div>
              <span className={`text-xs px-3 py-1 rounded-full capitalize ${typeColors[act.activity_type] || 'bg-slate-100 text-slate-600'}`}>
                {act.activity_type}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
