import { useEffect, useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import type { FamilyGroup, FamilyMemberWithProfile, Invitation } from '@/types/database';
import { UserPlus, Mail, Clock, Check, X, Copy, CheckCheck } from 'lucide-react';

export function FamilyView() {
  const { profile } = useAuth();
  const [familyGroups, setFamilyGroups] = useState<FamilyGroup[]>([]);
  const [members, setMembers] = useState<FamilyMemberWithProfile[]>([]);
  const [invitations, setInvitations] = useState<Invitation[]>([]);
  const [loading, setLoading] = useState(true);
  const [showInvite, setShowInvite] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteName, setInviteName] = useState('');
  const [inviteRole, setInviteRole] = useState<'student' | 'parent' | 'mentor'>('parent');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [copiedToken, setCopiedToken] = useState<string | null>(null);

  const loadData = async () => {
    if (!profile) return;
    const [{ data: fm }, { data: inv }] = await Promise.all([
      supabase.from('family_members').select('*, profiles:profiles(id, email, full_name, role)').order('joined_at', { ascending: false }),
      supabase.from('invitations').select('*').order('created_at', { ascending: false }),
    ]);
    const fmList = (fm as FamilyMemberWithProfile[]) || [];
    setMembers(fmList);

    const groupIds = [...new Set(fmList.map((m) => m.family_group_id))];
    if (groupIds.length > 0) {
      const { data: groups } = await supabase.from('family_groups').select('*').in('id', groupIds);
      setFamilyGroups((groups as FamilyGroup[]) || []);
    }

    setInvitations((inv as Invitation[]) || []);
    setLoading(false);
  };

  useEffect(() => {
    loadData();
  }, [profile]);

  const handleInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile || familyGroups.length === 0) return;
    setError(null);
    setSuccess(null);

    const { data, error: err } = await supabase
      .from('invitations')
      .insert({
        family_group_id: familyGroups[0].id,
        invited_email: inviteEmail,
        invited_name: inviteName,
        role_in_family: inviteRole,
        invited_by: profile.id,
      })
      .select()
      .single();

    if (err) {
      setError(err.message);
      return;
    }

    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-email`;
    const siteUrl = window.location.origin;
    const inviteUrl = `${siteUrl}/?invite=${(data as Invitation).token}`;
    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({
          type: 'family_invitation',
          recipient_email: inviteEmail,
          template_data: {
            recipientName: inviteName || inviteEmail,
            inviterName: profile.full_name || profile.email,
            role: inviteRole,
            inviteUrl,
            expiresAt: new Date((data as Invitation).expires_at).toLocaleDateString(),
          },
        }),
      });
      if (!response.ok) {
        const body = await response.json().catch(() => ({}));
        setError(`Invitation created but email could not be sent: ${body.error || response.statusText}. Share the link manually.`);
      } else {
        setSuccess(`Invitation sent to ${inviteEmail}. They will receive an email with a link to join.`);
      }
    } catch {
      setError('Invitation created but the email service was unreachable. Share the link manually.');
    }

    setInviteEmail('');
    setInviteName('');
    setShowInvite(false);
    loadData();
  };

  const handleRevoke = async (id: string) => {
    await supabase.from('invitations').update({ status: 'revoked' }).eq('id', id);
    loadData();
  };

  const copyInviteLink = (token: string) => {
    const url = `${window.location.origin}/?invite=${token}`;
    navigator.clipboard.writeText(url);
    setCopiedToken(token);
    setTimeout(() => setCopiedToken(null), 2000);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Family Dashboard</h2>
          <p className="text-slate-500 mt-1">Manage family members and invitations.</p>
        </div>
        <button
          onClick={() => setShowInvite(!showInvite)}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-lg text-sm font-medium transition-colors"
        >
          <UserPlus className="w-4 h-4" />
          Invite Member
        </button>
      </div>

      {error && <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg px-4 py-3">{error}</div>}
      {success && <div className="bg-green-50 border border-green-200 text-green-700 text-sm rounded-lg px-4 py-3">{success}</div>}

      {showInvite && (
        <form onSubmit={handleInvite} className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
          <h3 className="font-semibold text-slate-900">Invite a Family Member</h3>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Name</label>
              <input type="text" value={inviteName} onChange={(e) => setInviteName(e.target.value)} required
                className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none text-slate-900" placeholder="John Doe" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Email</label>
              <input type="email" value={inviteEmail} onChange={(e) => setInviteEmail(e.target.value)} required
                className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none text-slate-900" placeholder="john@example.com" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Role</label>
            <div className="grid grid-cols-3 gap-2">
              {(['student', 'parent', 'mentor'] as const).map((r) => (
                <button key={r} type="button" onClick={() => setInviteRole(r)}
                  className={`py-2.5 px-3 rounded-lg text-sm font-medium capitalize transition-all ${inviteRole === r ? 'bg-blue-600 text-white shadow-md' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>
                  {r}
                </button>
              ))}
            </div>
          </div>
          <div className="flex gap-3">
            <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-lg text-sm font-medium">Send Invitation</button>
            <button type="button" onClick={() => setShowInvite(false)} className="text-slate-600 hover:text-slate-800 px-5 py-2.5 rounded-lg text-sm font-medium">Cancel</button>
          </div>
        </form>
      )}

      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <h3 className="font-semibold text-slate-900 mb-4">Family Members</h3>
        {members.length === 0 ? (
          <p className="text-sm text-slate-400 text-center py-4">No family members yet. Invite someone to get started!</p>
        ) : (
          <div className="space-y-3">
            {members.map((m) => (
              <div key={m.id} className="flex items-center gap-3 py-3 border-b border-slate-100 last:border-0">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-teal-400 flex items-center justify-center text-white text-sm font-medium">
                  {(m.profiles?.full_name || m.profiles?.email || '?').split(' ').map((w) => w[0]).slice(0, 2).join('').toUpperCase()}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-slate-900">{m.profiles?.full_name || 'Unknown'}</p>
                  <p className="text-xs text-slate-400">{m.profiles?.email}</p>
                </div>
                <span className="text-xs px-3 py-1 rounded-full bg-slate-100 text-slate-600 capitalize">{m.role_in_family}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {invitations.length > 0 && (
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <h3 className="font-semibold text-slate-900 mb-4">Pending Invitations</h3>
          <div className="space-y-3">
            {invitations.map((inv) => (
              <div key={inv.id} className="flex items-center gap-3 py-3 border-b border-slate-100 last:border-0">
                <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center">
                  <Mail className="w-5 h-5 text-slate-400" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-slate-900">{inv.invited_name || inv.invited_email}</p>
                  <p className="text-xs text-slate-400">
                    {inv.invited_email} · Expires {new Date(inv.expires_at).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {inv.status === 'pending' ? (
                    <>
                      <span className="text-xs px-2 py-1 rounded-full bg-amber-50 text-amber-700 flex items-center gap-1">
                        <Clock className="w-3 h-3" /> Pending
                      </span>
                      <button onClick={() => copyInviteLink(inv.token)} className="p-2 rounded-lg hover:bg-slate-100 text-slate-500" title="Copy invite link">
                        {copiedToken === inv.token ? <CheckCheck className="w-4 h-4 text-green-600" /> : <Copy className="w-4 h-4" />}
                      </button>
                      <button onClick={() => handleRevoke(inv.id)} className="p-2 rounded-lg hover:bg-red-50 text-red-500" title="Revoke">
                        <X className="w-4 h-4" />
                      </button>
                    </>
                  ) : (
                    <span className={`text-xs px-2 py-1 rounded-full flex items-center gap-1 ${
                      inv.status === 'accepted' ? 'bg-green-50 text-green-700' :
                      inv.status === 'revoked' ? 'bg-red-50 text-red-700' : 'bg-slate-100 text-slate-600'
                    }`}>
                      {inv.status === 'accepted' && <Check className="w-3 h-3" />}
                      <span className="capitalize">{inv.status}</span>
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
