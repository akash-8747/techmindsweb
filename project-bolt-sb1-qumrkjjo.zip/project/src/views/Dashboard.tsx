import { useEffect, useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import type { Assessment, Activity, MonthlyReport, FamilyMemberWithProfile } from '@/types/database';
import {
  ClipboardCheck, FileText, TrendingUp, AlertCircle,
  Clock, Users, ArrowRight
} from 'lucide-react';
import type { ViewKey } from '@/components/AppLayout';

export function Dashboard({ onNavigate }: { onNavigate: (v: ViewKey) => void }) {
  const { profile } = useAuth();
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [reports, setReports] = useState<MonthlyReport[]>([]);
  const [familyMembers, setFamilyMembers] = useState<FamilyMemberWithProfile[]>([]);
  const [lastActivity, setLastActivity] = useState<Activity | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profile) return;
    (async () => {
      const [{ data: a }, { data: act }, { data: r }, { data: fm }] = await Promise.all([
        supabase.from('assessments').select('*').eq('student_id', profile.id).order('completed_at', { ascending: false }).limit(5),
        supabase.from('activities').select('*').eq('student_id', profile.id).order('activity_date', { ascending: false }).limit(10),
        supabase.from('monthly_reports').select('*').eq('student_id', profile.id).order('generated_at', { ascending: false }).limit(3),
        supabase.from('family_members').select('*, profiles:profiles(id, email, full_name, role)').order('joined_at', { ascending: false }),
      ]);
      setAssessments((a as Assessment[]) || []);
      setActivities((act as Activity[]) || []);
      setReports((r as MonthlyReport[]) || []);
      setFamilyMembers((fm as FamilyMemberWithProfile[]) || []);
      setLastActivity((act as Activity[])?.[0] ?? null);
      setLoading(false);
    })();
  }, [profile]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
      </div>
    );
  }

  const totalAssessments = assessments.length;
  const totalActivities = activities.length;
  const needsSupport = assessments.filter((a) => a.needs_additional_support).length;
  const daysSinceActivity = lastActivity
    ? Math.floor((Date.now() - new Date(lastActivity.activity_date).getTime()) / (1000 * 60 * 60 * 24))
    : null;

  const stats = [
    { label: 'Assessments', value: totalAssessments, icon: ClipboardCheck, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'Activities', value: totalActivities, icon: FileText, color: 'text-teal-600', bg: 'bg-teal-50' },
    { label: 'Reports', value: reports.length, icon: TrendingUp, color: 'text-purple-600', bg: 'bg-purple-50' },
    { label: 'Family Members', value: familyMembers.length, icon: Users, color: 'text-orange-600', bg: 'bg-orange-50' },
  ];

  return (
    <div className="space-y-6 max-w-6xl">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">
          Welcome back, {profile?.full_name || 'there'}!
        </h2>
        <p className="text-slate-500 mt-1">Here's an overview of your career journey progress.</p>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="bg-white rounded-xl border border-slate-200 p-5 hover:shadow-md transition-shadow">
              <div className={`w-10 h-10 rounded-lg ${s.bg} flex items-center justify-center mb-3`}>
                <Icon className={`w-5 h-5 ${s.color}`} />
              </div>
              <p className="text-2xl font-bold text-slate-900">{s.value}</p>
              <p className="text-sm text-slate-500">{s.label}</p>
            </div>
          );
        })}
      </div>

      {/* Activity status */}
      {daysSinceActivity !== null && (
        <div className={`rounded-xl border p-5 flex items-start gap-4 ${
          daysSinceActivity >= 30 ? 'bg-red-50 border-red-200' :
          daysSinceActivity >= 15 ? 'bg-amber-50 border-amber-200' :
          'bg-green-50 border-green-200'
        }`}>
          <Clock className={`w-6 h-6 flex-shrink-0 mt-0.5 ${
            daysSinceActivity >= 30 ? 'text-red-600' :
            daysSinceActivity >= 15 ? 'text-amber-600' : 'text-green-600'
          }`} />
          <div className="flex-1">
            <h3 className="font-semibold text-slate-900">Learning Activity Status</h3>
            <p className="text-sm text-slate-600 mt-1">
              {daysSinceActivity === 0
                ? "You've been active today — great job!"
                : `Your last learning activity was ${daysSinceActivity} day${daysSinceActivity === 1 ? '' : 's'} ago.`}
              {daysSinceActivity >= 15 && daysSinceActivity < 30 && ' Consider resuming your learning journey.'}
              {daysSinceActivity >= 30 && ' A follow-up may be needed. Please reach out to your mentor or family member.'}
            </p>
          </div>
        </div>
      )}

      {/* Support alert */}
      {needsSupport > 0 && (
        <div className="bg-orange-50 border border-orange-200 rounded-xl p-5 flex items-start gap-4">
          <AlertCircle className="w-6 h-6 text-orange-600 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <h3 className="font-semibold text-slate-900">Additional Support Available</h3>
            <p className="text-sm text-slate-600 mt-1">
              {needsSupport} assessment{needsSupport > 1 ? 's' : ''} indicate{needsSupport > 1 ? '' : 's'} you may benefit from additional support. Consider scheduling a mentoring session.
            </p>
            <button
              onClick={() => onNavigate('assessments')}
              className="text-sm font-medium text-orange-700 hover:text-orange-800 mt-2 flex items-center gap-1"
            >
              View assessments <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Recent activity */}
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-slate-900">Recent Assessments</h3>
            <button onClick={() => onNavigate('assessments')} className="text-sm text-blue-600 hover:text-blue-700">View all</button>
          </div>
          {assessments.length === 0 ? (
            <p className="text-sm text-slate-400 py-4 text-center">No assessments yet. Take your first career assessment to get started!</p>
          ) : (
            <div className="space-y-3">
              {assessments.slice(0, 4).map((a) => (
                <div key={a.id} className="flex items-center justify-between py-2 border-b border-slate-100 last:border-0">
                  <div>
                    <p className="text-sm font-medium text-slate-900">{a.title}</p>
                    <p className="text-xs text-slate-400">{new Date(a.completed_at).toLocaleDateString()}</p>
                  </div>
                  <span className={`text-sm font-semibold ${a.needs_additional_support ? 'text-orange-600' : 'text-green-600'}`}>
                    {a.score !== null ? `${a.score}/${a.max_score}` : '—'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-slate-900">Recent Activities</h3>
            <button onClick={() => onNavigate('activities')} className="text-sm text-blue-600 hover:text-blue-700">View all</button>
          </div>
          {activities.length === 0 ? (
            <p className="text-sm text-slate-400 py-4 text-center">No learning activities yet. Start by exploring the learning planner!</p>
          ) : (
            <div className="space-y-3">
              {activities.slice(0, 5).map((act) => (
                <div key={act.id} className="flex items-center justify-between py-2 border-b border-slate-100 last:border-0">
                  <div>
                    <p className="text-sm font-medium text-slate-900">{act.description}</p>
                    <p className="text-xs text-slate-400">{new Date(act.activity_date).toLocaleDateString()}</p>
                  </div>
                  <span className="text-xs px-2 py-1 rounded-full bg-slate-100 text-slate-600 capitalize">{act.activity_type}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
