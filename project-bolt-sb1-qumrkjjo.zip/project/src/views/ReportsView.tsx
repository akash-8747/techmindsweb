import { useEffect, useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import type { MonthlyReport, Assessment, Activity } from '@/types/database';
import { FileText, TrendingUp, RefreshCw } from 'lucide-react';

export function ReportsView() {
  const { profile } = useAuth();
  const [reports, setReports] = useState<MonthlyReport[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    if (!profile) return;
    const { data } = await supabase
      .from('monthly_reports')
      .select('*')
      .eq('student_id', profile.id)
      .order('report_month', { ascending: false });
    setReports((data as MonthlyReport[]) || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, [profile]);

  const handleGenerate = async () => {
    if (!profile) return;
    setGenerating(true);
    setError(null);

    const now = new Date();
    const reportMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
    const monthEnd = now.toISOString();

    const [{ data: assessments }, { data: activities }] = await Promise.all([
      supabase.from('assessments').select('*').eq('student_id', profile.id).gte('completed_at', monthStart).lte('completed_at', monthEnd),
      supabase.from('activities').select('*').eq('student_id', profile.id).gte('activity_date', monthStart).lte('activity_date', monthEnd),
    ]);

    const aList = (assessments as Assessment[]) || [];
    const actList = (activities as Activity[]) || [];
    const types = new Set(actList.map((a) => a.activity_type));

    const { error: err } = await supabase.from('monthly_reports').upsert({
      student_id: profile.id,
      report_month: reportMonth,
      assessments_completed: aList.length,
      activities_completed: actList.length,
      skill_progress: `${types.size} skill ${types.size === 1 ? 'area' : 'areas'} explored`,
      career_progress: aList.length > 0 ? `${aList.length} assessment${aList.length > 1 ? 's' : ''} completed this month` : 'No assessments completed yet',
      outstanding_tasks: aList.filter((a) => a.needs_additional_support).length > 0 ? 'Review assessments flagged for additional support' : 'No outstanding tasks',
      recommended_next_steps: actList.length < 5 ? 'Increase learning frequency — aim for at least 5 activities per month' : 'Great consistency — continue current pace',
    }, { onConflict: 'student_id,report_month' });

    if (err) { setError(err.message); setGenerating(false); return; }
    setGenerating(false);
    load();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Monthly Reports</h2>
          <p className="text-slate-500 mt-1">Your monthly progress reports are generated from real activity data.</p>
        </div>
        <button onClick={handleGenerate} disabled={generating}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-lg text-sm font-medium disabled:opacity-60">
          {generating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <TrendingUp className="w-4 h-4" />}
          Generate Report
        </button>
      </div>

      {error && <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg px-4 py-3">{error}</div>}

      {reports.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500">No reports yet. Click "Generate Report" to create one from your activity data.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {reports.map((r) => (
            <div key={r.id} className="bg-white rounded-xl border border-slate-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-slate-900">
                  {new Date(r.report_month).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                </h3>
                <span className="text-xs text-slate-400">Generated {new Date(r.generated_at).toLocaleDateString()}</span>
              </div>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="bg-blue-50 rounded-lg p-4">
                  <p className="text-3xl font-bold text-blue-700">{r.assessments_completed}</p>
                  <p className="text-sm text-slate-600">Assessments Completed</p>
                </div>
                <div className="bg-teal-50 rounded-lg p-4">
                  <p className="text-3xl font-bold text-teal-700">{r.activities_completed}</p>
                  <p className="text-sm text-slate-600">Activities Completed</p>
                </div>
              </div>
              <div className="space-y-2 text-sm">
                <p className="text-slate-600"><strong className="text-slate-900">Skill Development:</strong> {r.skill_progress}</p>
                <p className="text-slate-600"><strong className="text-slate-900">Career Preparation:</strong> {r.career_progress}</p>
                <p className="text-slate-600"><strong className="text-slate-900">Outstanding Tasks:</strong> {r.outstanding_tasks}</p>
                <p className="text-slate-600"><strong className="text-slate-900">Recommended Next Steps:</strong> {r.recommended_next_steps}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
