export type UserRole = 'student' | 'parent' | 'mentor';

export type NotificationType =
  | 'welcome'
  | 'family_invitation'
  | 'inactivity_15'
  | 'inactivity_30'
  | 'monthly_report'
  | 'additional_support'
  | 'follow_up'
  | 'test';

export type NotificationStatus = 'pending' | 'sent' | 'failed' | 'retrying';

export type InvitationStatus = 'pending' | 'accepted' | 'expired' | 'revoked';

export interface Profile {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  timezone: string;
  email_verified: boolean;
  created_at: string;
  updated_at: string;
}

export interface FamilyGroup {
  id: string;
  name: string;
  created_by: string;
  created_at: string;
}

export interface FamilyMember {
  id: string;
  family_group_id: string;
  user_id: string;
  role_in_family: UserRole;
  joined_at: string;
}

export interface Invitation {
  id: string;
  family_group_id: string;
  invited_email: string;
  invited_by: string;
  invited_name: string;
  role_in_family: UserRole;
  token: string;
  status: InvitationStatus;
  expires_at: string;
  accepted_at: string | null;
  accepted_by: string | null;
  created_at: string;
}

export interface Assessment {
  id: string;
  student_id: string;
  family_group_id: string | null;
  title: string;
  score: number | null;
  max_score: number;
  needs_additional_support: boolean;
  support_notes: string;
  completed_at: string;
  created_at: string;
}

export interface Activity {
  id: string;
  student_id: string;
  family_group_id: string | null;
  activity_type: string;
  description: string;
  activity_date: string;
  created_at: string;
}

export interface MonthlyReport {
  id: string;
  student_id: string;
  family_group_id: string | null;
  report_month: string;
  assessments_completed: number;
  activities_completed: number;
  skill_progress: string;
  career_progress: string;
  outstanding_tasks: string;
  recommended_next_steps: string;
  generated_at: string;
}

export interface NotificationPreferences {
  id: string;
  user_id: string;
  email_enabled: boolean;
  monthly_report_enabled: boolean;
  learning_reminder_enabled: boolean;
  parent_notifications_enabled: boolean;
  mentor_notifications_enabled: boolean;
  support_alerts_enabled: boolean;
  updated_at: string;
}

export interface NotificationLogEntry {
  id: string;
  user_id: string | null;
  recipient_email: string;
  notification_type: NotificationType;
  subject: string;
  status: NotificationStatus;
  provider_message_id: string | null;
  error_message: string | null;
  retry_count: number;
  dedup_key: string | null;
  sent_at: string | null;
  created_at: string;
}

export interface FamilyMemberWithProfile extends FamilyMember {
  profiles: Pick<Profile, 'id' | 'email' | 'full_name' | 'role'> | null;
}
