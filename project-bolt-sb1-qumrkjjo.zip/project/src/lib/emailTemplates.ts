export interface EmailTemplateData {
  recipientName: string;
  [key: string]: string | undefined;
}

export interface EmailTemplate {
  subject: string;
  text: string;
  html: string;
}

const baseStyles = `
  <body style="margin:0;padding:0;background-color:#f8fafc;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">
    <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#f8fafc;padding:24px 0;">
      <tr><td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
          <tr>
            <td style="background:linear-gradient(135deg,#2563eb,#0d9488);padding:32px 40px;text-align:center;">
              <h1 style="margin:0;color:#ffffff;font-size:24px;font-weight:700;">Career Setu AI</h1>
              <p style="margin:8px 0 0;color:#c7e0f4;font-size:14px;">Your AI-powered career guidance platform</p>
            </td>
          </tr>
          <tr><td style="padding:32px 40px;">
`;

const footerStyles = `
          </td></tr>
          <tr>
            <td style="padding:24px 40px;background-color:#f1f5f9;border-top:1px solid #e2e8f0;">
              <p style="margin:0;color:#64748b;font-size:12px;text-align:center;line-height:1.6;">
                You received this email because you have a Career Setu AI account.<br/>
                If you believe this was sent in error, please contact your administrator.
              </p>
              <p style="margin:8px 0 0;color:#94a3b8;font-size:11px;text-align:center;">
                &copy; 2026 Career Setu AI. All rights reserved.
              </p>
            </td>
          </tr>
        </table>
      </td></tr>
    </table>
  </body>
`;

function wrapContent(content: string): string {
  return baseStyles + content + footerStyles;
}

export function welcomeEmail(data: EmailTemplateData): EmailTemplate {
  const subject = 'Welcome to Career Setu AI';
  const body = `
    <h2 style="margin:0 0 16px;color:#1e293b;font-size:20px;">Welcome, ${data.recipientName}!</h2>
    <p style="margin:0 0 16px;color:#475569;font-size:15px;line-height:1.6;">
      Thank you for joining Career Setu AI, your personalized career guidance platform.
      We are excited to help you discover your strengths, explore career paths, and build the skills you need for success.
    </p>
    <h3 style="margin:24px 0 12px;color:#1e293b;font-size:16px;">Next Steps</h3>
    <ul style="margin:0 0 24px;padding-left:20px;color:#475569;font-size:15px;line-height:1.8;">
      <li>Complete your profile to get personalized recommendations</li>
      <li>Take your first career assessment to identify your strengths</li>
      <li>Explore the learning planner to start building skills</li>
      <li>Invite family members to join your family dashboard</li>
    </ul>
    <a href="${data.dashboardUrl || '#'}" style="display:inline-block;background-color:#2563eb;color:#ffffff;text-decoration:none;padding:12px 28px;border-radius:8px;font-size:15px;font-weight:600;">Go to Dashboard</a>
  `;
  return {
    subject,
    text: `Welcome to Career Setu AI!\n\nThank you for joining, ${data.recipientName}. Complete your profile and take your first career assessment to get started.\n\nVisit your dashboard: ${data.dashboardUrl || ''}`,
    html: wrapContent(body),
  };
}

export function familyInvitationEmail(data: EmailTemplateData): EmailTemplate {
  const subject = 'Invitation to join a Career Setu AI family dashboard';
  const body = `
    <h2 style="margin:0 0 16px;color:#1e293b;font-size:20px;">You're Invited!</h2>
    <p style="margin:0 0 16px;color:#475569;font-size:15px;line-height:1.6;">
      ${data.inviterName || 'A family member'} has invited you to join their Career Setu AI family dashboard
      as a ${data.role || 'family member'}.
    </p>
    <p style="margin:0 0 24px;color:#475569;font-size:15px;line-height:1.6;">
      By accepting this invitation, you'll be able to view shared progress reports,
      learning activities, and support each other's career journey.
    </p>
    <a href="${data.inviteUrl || '#'}" style="display:inline-block;background-color:#0d9488;color:#ffffff;text-decoration:none;padding:12px 28px;border-radius:8px;font-size:15px;font-weight:600;">Accept Invitation</a>
    <p style="margin:16px 0 0;color:#94a3b8;font-size:13px;">
      This invitation expires on ${data.expiresAt || 'the expiration date'}.
      If you do not know the sender, please ignore this email.
    </p>
  `;
  return {
    subject,
    text: `You're invited to join a Career Setu AI family dashboard!\n\n${data.inviterName || 'A family member'} has invited you to join as a ${data.role || 'family member'}.\n\nAccept the invitation: ${data.inviteUrl || ''}\n\nThis invitation expires on ${data.expiresAt || 'the expiration date'}.`,
    html: wrapContent(body),
  };
}

export function inactivity15Email(data: EmailTemplateData): EmailTemplate {
  const subject = 'Career Setu AI — Learning progress reminder';
  const body = `
    <h2 style="margin:0 0 16px;color:#1e293b;font-size:20px;">Hi ${data.recipientName}, we miss you!</h2>
    <p style="margin:0 0 16px;color:#475569;font-size:15px;line-height:1.6;">
      It's been a little while since your last learning activity on Career Setu AI.
      Your last recorded activity was on <strong>${data.lastActivityDate || 'recently'}</strong>.
    </p>
    <p style="margin:0 0 24px;color:#475569;font-size:15px;line-height:1.6;">
      Consistency is key to building your career skills. Even 15 minutes a day can make
      a big difference. Pick up where you left off and keep moving forward!
    </p>
    <a href="${data.plannerUrl || '#'}" style="display:inline-block;background-color:#2563eb;color:#ffffff;text-decoration:none;padding:12px 28px;border-radius:8px;font-size:15px;font-weight:600;">Resume Learning</a>
  `;
  return {
    subject,
    text: `Hi ${data.recipientName},\n\nIt's been a while since your last learning activity (last activity: ${data.lastActivityDate || 'recently'}). Consistency is key — pick up where you left off!\n\nResume learning: ${data.plannerUrl || ''}`,
    html: wrapContent(body),
  };
}

export function inactivity30Email(data: EmailTemplateData): EmailTemplate {
  const subject = 'Career Setu AI — Student progress follow-up required';
  const body = `
    <h2 style="margin:0 0 16px;color:#1e293b;font-size:20px;">Follow-up Needed: ${data.studentName || data.recipientName}</h2>
    <p style="margin:0 0 16px;color:#475569;font-size:15px;line-height:1.6;">
      It has been 30 days since ${data.studentName || 'the student'} last engaged with Career Setu AI.
      The last recorded activity was on <strong>${data.lastActivityDate || 'over 30 days ago'}</strong>.
    </p>
    <h3 style="margin:24px 0 12px;color:#1e293b;font-size:16px;">Suggested Follow-up Actions</h3>
    <ul style="margin:0 0 24px;padding-left:20px;color:#475569;font-size:15px;line-height:1.8;">
      <li>Reach out to the student to understand any challenges they're facing</li>
      <li>Review the learning plan and adjust goals if needed</li>
      <li>Consider scheduling a mentoring or counselling session</li>
      <li>Encourage the student to resume with a smaller, manageable task</li>
    </ul>
    <a href="${data.dashboardUrl || '#'}" style="display:inline-block;background-color:#2563eb;color:#ffffff;text-decoration:none;padding:12px 28px;border-radius:8px;font-size:15px;font-weight:600;">View Dashboard</a>
  `;
  return {
    subject,
    text: `Follow-up required: ${data.studentName || data.recipientName} has been inactive for 30 days.\n\nLast activity: ${data.lastActivityDate || 'over 30 days ago'}\n\nSuggested actions: reach out to the student, review the learning plan, consider scheduling a mentoring session.\n\nView dashboard: ${data.dashboardUrl || ''}`,
    html: wrapContent(body),
  };
}

export function monthlyReportEmail(data: EmailTemplateData): EmailTemplate {
  const subject = 'Your monthly Career Setu AI progress report';
  const body = `
    <h2 style="margin:0 0 16px;color:#1e293b;font-size:20px;">Monthly Progress Report</h2>
    <p style="margin:0 0 16px;color:#475569;font-size:15px;line-height:1.6;">
      Reporting period: <strong>${data.reportPeriod || 'this month'}</strong>
    </p>
    <table width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 24px;">
      <tr><td style="padding:12px 16px;background-color:#f1f5f9;border-radius:8px 8px 0 0;color:#1e293b;font-size:14px;font-weight:600;border-bottom:1px solid #e2e8f0;">Assessments Completed</td><td style="padding:12px 16px;background-color:#f1f5f9;border-radius:8px 8px 0 0;color:#2563eb;font-size:14px;font-weight:700;text-align:right;border-bottom:1px solid #e2e8f0;">${data.assessmentsCompleted || '0'}</td></tr>
      <tr><td style="padding:12px 16px;background-color:#f8fafc;color:#1e293b;font-size:14px;font-weight:600;border-bottom:1px solid #e2e8f0;">Learning Activities</td><td style="padding:12px 16px;background-color:#f8fafc;color:#2563eb;font-size:14px;font-weight:700;text-align:right;border-bottom:1px solid #e2e8f0;">${data.activitiesCompleted || '0'}</td></tr>
      <tr><td style="padding:12px 16px;background-color:#f1f5f9;border-radius:0 0 8px 8px;color:#1e293b;font-size:14px;font-weight:600;">Skill Development</td><td style="padding:12px 16px;background-color:#f1f5f9;border-radius:0 0 8px 8px;color:#2563eb;font-size:14px;font-weight:700;text-align:right;">${data.skillProgress || 'In progress'}</td></tr>
    </table>
    ${data.careerProgress ? `<p style="margin:0 0 16px;color:#475569;font-size:15px;line-height:1.6;"><strong>Career Preparation:</strong> ${data.careerProgress}</p>` : ''}
    ${data.outstandingTasks ? `<p style="margin:0 0 16px;color:#475569;font-size:15px;line-height:1.6;"><strong>Outstanding Tasks:</strong> ${data.outstandingTasks}</p>` : ''}
    ${data.recommendedNextSteps ? `<p style="margin:0 0 24px;color:#475569;font-size:15px;line-height:1.6;"><strong>Recommended Next Steps:</strong> ${data.recommendedNextSteps}</p>` : ''}
    <a href="${data.dashboardUrl || '#'}" style="display:inline-block;background-color:#2563eb;color:#ffffff;text-decoration:none;padding:12px 28px;border-radius:8px;font-size:15px;font-weight:600;">View Full Report</a>
  `;
  return {
    subject,
    text: `Monthly Progress Report — ${data.reportPeriod || 'this month'}\n\nAssessments completed: ${data.assessmentsCompleted || '0'}\nLearning activities: ${data.activitiesCompleted || '0'}\nSkill development: ${data.skillProgress || 'In progress'}\n${data.careerProgress ? `Career preparation: ${data.careerProgress}\n` : ''}${data.outstandingTasks ? `Outstanding tasks: ${data.outstandingTasks}\n` : ''}${data.recommendedNextSteps ? `Recommended next steps: ${data.recommendedNextSteps}\n` : ''}\nView full report: ${data.dashboardUrl || ''}`,
    html: wrapContent(body),
  };
}

export function additionalSupportEmail(data: EmailTemplateData): EmailTemplate {
  const subject = 'Career Setu AI — Additional learning support available';
  const body = `
    <h2 style="margin:0 0 16px;color:#1e293b;font-size:20px;">Additional Support Available</h2>
    <p style="margin:0 0 16px;color:#475569;font-size:15px;line-height:1.6;">
      Hi ${data.recipientName},
    </p>
    <p style="margin:0 0 16px;color:#475569;font-size:15px;line-height:1.6;">
      Based on recent assessment results, we believe ${data.studentName || 'the student'} may benefit from
      additional learning support. This is completely normal and part of the learning journey —
      our platform is designed to identify areas where extra guidance can help.
    </p>
    <h3 style="margin:24px 0 12px;color:#1e293b;font-size:16px;">Suggested Actions</h3>
    <ul style="margin:0 0 24px;padding-left:20px;color:#475569;font-size:15px;line-height:1.8;">
      <li>Schedule a one-on-one session with a mentor or counsellor</li>
      <li>Review the assessment results together to identify focus areas</li>
      <li>Adjust the learning plan to include additional practice in key areas</li>
      <li>Set smaller, achievable goals to build confidence</li>
    </ul>
    <a href="${data.dashboardUrl || '#'}" style="display:inline-block;background-color:#0d9488;color:#ffffff;text-decoration:none;padding:12px 28px;border-radius:8px;font-size:15px;font-weight:600;">View Dashboard</a>
  `;
  return {
    subject,
    text: `Hi ${data.recipientName},\n\nBased on recent assessment results, ${data.studentName || 'the student'} may benefit from additional learning support.\n\nSuggested actions: schedule a mentoring session, review assessment results, adjust the learning plan, set smaller achievable goals.\n\nView dashboard: ${data.dashboardUrl || ''}`,
    html: wrapContent(body),
  };
}

export function testEmail(data: EmailTemplateData): EmailTemplate {
  const subject = 'Career Setu AI — Test Email';
  const body = `
    <h2 style="margin:0 0 16px;color:#1e293b;font-size:20px;">Test Email Successful</h2>
    <p style="margin:0 0 16px;color:#475569;font-size:15px;line-height:1.6;">
      Hello ${data.recipientName}, this is a test email from Career Setu AI.
      If you received this message, your Gmail API integration is working correctly.
    </p>
    <p style="margin:0 0 16px;color:#475569;font-size:15px;line-height:1.6;">
      Sent at: ${new Date().toISOString()}
    </p>
  `;
  return {
    subject,
    text: `Career Setu AI — Test Email\n\nHello ${data.recipientName}, this is a test email. If you received this, your Gmail API integration is working correctly.\n\nSent at: ${new Date().toISOString()}`,
    html: wrapContent(body),
  };
}

export function getTemplate(type: string, data: EmailTemplateData): EmailTemplate | null {
  switch (type) {
    case 'welcome': return welcomeEmail(data);
    case 'family_invitation': return familyInvitationEmail(data);
    case 'inactivity_15': return inactivity15Email(data);
    case 'inactivity_30': return inactivity30Email(data);
    case 'monthly_report': return monthlyReportEmail(data);
    case 'additional_support': return additionalSupportEmail(data);
    case 'test': return testEmail(data);
    case 'follow_up': return inactivity30Email(data);
    default: return null;
  }
}
