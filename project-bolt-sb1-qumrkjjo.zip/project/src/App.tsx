import { useState } from 'react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { AuthScreen } from '@/components/AuthScreen';
import { AppLayout, type ViewKey } from '@/components/AppLayout';
import { Dashboard } from '@/views/Dashboard';
import { FamilyView } from '@/views/FamilyView';
import { AssessmentsView } from '@/views/AssessmentsView';
import { ActivitiesView } from '@/views/ActivitiesView';
import { ReportsView } from '@/views/ReportsView';
import { NotificationSettingsView } from '@/views/NotificationSettingsView';
import { NotificationHistoryView } from '@/views/NotificationHistoryView';
import { Loader2 } from 'lucide-react';

function AppContent() {
  const { user, loading } = useAuth();
  const [view, setView] = useState<ViewKey>('dashboard');

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (!user) {
    return <AuthScreen />;
  }

  return (
    <AppLayout currentView={view} onNavigate={setView}>
      {view === 'dashboard' && <Dashboard onNavigate={setView} />}
      {view === 'family' && <FamilyView />}
      {view === 'assessments' && <AssessmentsView />}
      {view === 'activities' && <ActivitiesView />}
      {view === 'reports' && <ReportsView />}
      {view === 'notifications' && <NotificationHistoryView />}
      {view === 'settings' && <NotificationSettingsView />}
    </AppLayout>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
