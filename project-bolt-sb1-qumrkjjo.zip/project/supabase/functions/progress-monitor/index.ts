import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface ProfileRow {
  id: string;
  email: string;
  full_name: string;
  role: string;
  timezone: string;
}

interface ActivityRow {
  activity_date: string;
}

interface FamilyMemberRow {
  user_id: string;
  role_in_family: string;
  profiles: { email: string; full_name: string } | null;
}

interface PreferencesRow {
  email_enabled: boolean;
  monthly_report_enabled: boolean;
  learning_reminder_enabled: boolean;
  parent_notifications_enabled: boolean;
  mentor_notifications_enabled: boolean;
  support_alerts_enabled: boolean;
}

async function sendEmailViaEdgeFunction(
  supabaseUrl: string,
  serviceKey: string,
  type: string,
  recipientEmail: string,
  recipientUserId: string | null,
  templateData: Record<string, string | undefined>,
  dedupKey: string
): Promise<{ success: boolean; error?: string }> {
  const response = await fetch(`${supabaseUrl}/functions/v1/send-email`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${serviceKey}`,
    },
    body: JSON.stringify({
      type,
      recipient_email: recipientEmail,
      recipient_user_id: recipientUserId,
      template_data: templateData,
      dedup_key: dedupKey,
    }),
  });

  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    return { success: false, error: body.error || `HTTP ${response.status}` };
  }

  return { success: true };
}

function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceKey);
    const siteUrl = Deno.env.get("SITE_URL") || "https://career-setu-ai-platf-625l.bolt.host";
    const results: string[] = [];

    // 1. Find all students and their last activity
    const { data: students } = await supabase
      .from("profiles")
      .select("id, email, full_name, role, timezone")
      .eq("role", "student")
      .returns<ProfileRow[]>();

    if (!students || students.length === 0) {
      return new Response(
        JSON.stringify({ message: "No students found", actions: results }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const now = new Date();
    const monthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
    const reportMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split("T")[0];
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
    const monthEnd = now.toISOString();

    for (const student of students) {
      // Get last activity
      const { data: lastActivity } = await supabase
        .from("activities")
        .select("activity_date")
        .eq("student_id", student.id)
        .order("activity_date", { ascending: false })
        .limit(1)
        .returns<ActivityRow[]>();

      const lastActivityDate = lastActivity?.[0]?.activity_date;
      const daysInactive = lastActivityDate
        ? Math.floor((now.getTime() - new Date(lastActivityDate).getTime()) / (1000 * 60 * 60 * 24))
        : null;

      // Get preferences
      const { data: prefs } = await supabase
        .from("notification_preferences")
        .select("*")
        .eq("user_id", student.id)
        .maybeSingle()
        .returns<PreferencesRow | null>();

      const studentPrefs = prefs || {
        email_enabled: true,
        monthly_report_enabled: true,
        learning_reminder_enabled: true,
        parent_notifications_enabled: true,
        mentor_notifications_enabled: true,
        support_alerts_enabled: true,
      };

      if (!studentPrefs.email_enabled) {
        results.push(`Student ${student.email}: email disabled, skipping`);
        continue;
      }

      const dashboardUrl = `${siteUrl}`;
      const plannerUrl = `${siteUrl}`;

      // 2. Inactivity reminders
      if (daysInactive !== null && studentPrefs.learning_reminder_enabled) {
        if (daysInactive >= 15 && daysInactive < 30) {
          const dedupKey = `inactivity_15:${student.id}:${monthKey}`;
          const { success, error } = await sendEmailViaEdgeFunction(
            supabaseUrl, serviceKey, "inactivity_15",
            student.email, student.id,
            {
              recipientName: student.full_name || student.email,
              lastActivityDate: formatDate(lastActivityDate),
              plannerUrl,
            },
            dedupKey
          );
          results.push(`Student ${student.email}: 15-day reminder ${success ? "sent" : "failed: " + error}`);
        }

        if (daysInactive >= 30) {
          const dedupKey = `inactivity_30:${student.id}:${monthKey}`;
          const { success, error } = await sendEmailViaEdgeFunction(
            supabaseUrl, serviceKey, "inactivity_30",
            student.email, student.id,
            {
              recipientName: student.full_name || student.email,
              studentName: student.full_name || student.email,
              lastActivityDate: formatDate(lastActivityDate),
              dashboardUrl,
            },
            dedupKey
          );
          results.push(`Student ${student.email}: 30-day alert ${success ? "sent" : "failed: " + error}`);

          // Also notify parents/mentors in the family
          const { data: familyMembers } = await supabase
            .from("family_members")
            .select("user_id, role_in_family, profiles:profiles(email, full_name)")
            .eq("family_group_id",
              (await supabase
                .from("family_members")
                .select("family_group_id")
                .eq("user_id", student.id)
                .limit(1)
                .maybeSingle()
              ).data?.family_group_id
            )
            .neq("user_id", student.id)
            .returns<FamilyMemberRow[]>();

          if (familyMembers) {
            for (const fm of familyMembers) {
              const shouldNotify =
                (fm.role_in_family === "parent" && studentPrefs.parent_notifications_enabled) ||
                (fm.role_in_family === "mentor" && studentPrefs.mentor_notifications_enabled);
              if (shouldNotify && fm.profiles?.email) {
                const fmDedupKey = `inactivity_30_notify:${student.id}:${fm.user_id}:${monthKey}`;
                await sendEmailViaEdgeFunction(
                  supabaseUrl, serviceKey, "follow_up",
                  fm.profiles.email, fm.user_id,
                  {
                    recipientName: fm.profiles.full_name || fm.profiles.email,
                    studentName: student.full_name || student.email,
                    lastActivityDate: formatDate(lastActivityDate),
                    dashboardUrl,
                  },
                  fmDedupKey
                );
                results.push(`Parent/mentor ${fm.profiles.email}: 30-day follow-up sent for student ${student.email}`);
              }
            }
          }
        }
      }

      // 3. Additional support check
      const { data: supportAssessments } = await supabase
        .from("assessments")
        .select("id, title, completed_at")
        .eq("student_id", student.id)
        .eq("needs_additional_support", true)
        .gte("completed_at", new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString());

      if (supportAssessments && supportAssessments.length > 0 && studentPrefs.support_alerts_enabled) {
        const dedupKey = `additional_support:${student.id}:${monthKey}`;
        const { success, error } = await sendEmailViaEdgeFunction(
          supabaseUrl, serviceKey, "additional_support",
          student.email, student.id,
          {
            recipientName: student.full_name || student.email,
            studentName: student.full_name || student.email,
            dashboardUrl,
          },
          dedupKey
        );
        results.push(`Student ${student.email}: support alert ${success ? "sent" : "failed: " + error}`);
      }

      // 4. Monthly report generation
      if (studentPrefs.monthly_report_enabled) {
        const { data: existingReport } = await supabase
          .from("monthly_reports")
          .select("id")
          .eq("student_id", student.id)
          .eq("report_month", reportMonth)
          .maybeSingle();

        if (!existingReport) {
          const [{ data: monthAssessments }, { data: monthActivities }] = await Promise.all([
            supabase.from("assessments").select("id, needs_additional_support").eq("student_id", student.id).gte("completed_at", monthStart).lte("completed_at", monthEnd),
            supabase.from("activities").select("id, activity_type").eq("student_id", student.id).gte("activity_date", monthStart).lte("activity_date", monthEnd),
          ]);

          const aCount = monthAssessments?.length || 0;
          const actCount = monthActivities?.length || 0;
          const types = new Set((monthActivities || []).map((a: any) => a.activity_type));

          const skillProgress = `${types.size} skill ${types.size === 1 ? "area" : "areas"} explored`;
          const careerProgress = aCount > 0 ? `${aCount} assessment${aCount > 1 ? "s" : ""} completed` : "No assessments completed yet";
          const outstandingTasks = (monthAssessments || []).filter((a: any) => a.needs_additional_support).length > 0
            ? "Review assessments flagged for additional support"
            : "No outstanding tasks";
          const recommendedNextSteps = actCount < 5
            ? "Increase learning frequency — aim for at least 5 activities per month"
            : "Great consistency — continue current pace";

          await supabase.from("monthly_reports").upsert({
            student_id: student.id,
            report_month: reportMonth,
            assessments_completed: aCount,
            activities_completed: actCount,
            skill_progress: skillProgress,
            career_progress: careerProgress,
            outstanding_tasks: outstandingTasks,
            recommended_next_steps: recommendedNextSteps,
          }, { onConflict: "student_id,report_month" });

          const reportPeriod = new Date(now.getFullYear(), now.getMonth(), 1).toLocaleDateString("en-US", {
            month: "long", year: "numeric",
          });

          const dedupKey = `monthly_report:${student.id}:${reportMonth}`;
          const { success, error } = await sendEmailViaEdgeFunction(
            supabaseUrl, serviceKey, "monthly_report",
            student.email, student.id,
            {
              recipientName: student.full_name || student.email,
              reportPeriod,
              assessmentsCompleted: String(aCount),
              activitiesCompleted: String(actCount),
              skillProgress,
              careerProgress,
              outstandingTasks,
              recommendedNextSteps,
              dashboardUrl,
            },
            dedupKey
          );
          results.push(`Student ${student.email}: monthly report ${success ? "generated and sent" : "failed: " + error}`);
        } else {
          results.push(`Student ${student.email}: monthly report already exists for ${reportMonth}`);
        }
      }
    }

    return new Response(
      JSON.stringify({ success: true, students_processed: students.length, actions: results }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    const errorMessage = err instanceof Error ? err.message : String(err);
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

