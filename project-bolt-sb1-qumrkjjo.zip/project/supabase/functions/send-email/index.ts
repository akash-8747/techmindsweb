import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface SendEmailRequest {
  type: "welcome" | "family_invitation" | "inactivity_15" | "inactivity_30" | "monthly_report" | "additional_support" | "follow_up" | "test";
  recipient_email: string;
  recipient_user_id?: string;
  template_data: Record<string, string | undefined>;
  dedup_key?: string;
}

interface EmailContent {
  subject: string;
  text: string;
  html: string;
}

// ---- Email template generation (inline, no cross-function imports) ----

function generateEmail(type: string, data: Record<string, string | undefined>): EmailContent {
  const recipientName = data.recipientName || "there";
  const dashboardUrl = data.dashboardUrl || "";
  const baseHeader = `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"></head>`;
  const bodyOpen = `<body style="margin:0;padding:0;background-color:#f8fafc;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;"><table width="100%" cellpadding="0" cellspacing="0" style="background-color:#f8fafc;padding:24px 0;"><tr><td align="center"><table width="600" cellpadding="0" cellspacing="0" style="background-color:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,0.1);"><tr><td style="background:linear-gradient(135deg,#2563eb,#0d9488);padding:32px 40px;text-align:center;"><h1 style="margin:0;color:#ffffff;font-size:24px;font-weight:700;">Career Setu AI</h1><p style="margin:8px 0 0;color:#c7e0f4;font-size:14px;">Your AI-powered career guidance platform</p></td></tr><tr><td style="padding:32px 40px;">`;
  const bodyClose = `</td></tr><tr><td style="padding:24px 40px;background-color:#f1f5f9;border-top:1px solid #e2e8f0;"><p style="margin:0;color:#64748b;font-size:12px;text-align:center;line-height:1.6;">You received this email because you have a Career Setu AI account.<br/>If you believe this was sent in error, please contact your administrator.</p><p style="margin:8px 0 0;color:#94a3b8;font-size:11px;text-align:center;">&copy; 2026 Career Setu AI. All rights reserved.</p></td></tr></table></td></tr></table></body></html>`;
  const wrap = (c: string) => `${baseHeader}${bodyOpen}${c}${bodyClose}`;
  const btn = (url: string, label: string, color = "#2563eb") =>
    `<a href="${url}" style="display:inline-block;background-color:${color};color:#ffffff;text-decoration:none;padding:12px 28px;border-radius:8px;font-size:15px;font-weight:600;">${label}</a>`;

  switch (type) {
    case "welcome":
      return {
        subject: "Welcome to Career Setu AI",
        text: `Welcome to Career Setu AI!\n\nThank you for joining, ${recipientName}. Complete your profile and take your first career assessment to get started.\n\nVisit your dashboard: ${dashboardUrl}`,
        html: wrap(`<h2 style="margin:0 0 16px;color:#1e293b;font-size:20px;">Welcome, ${recipientName}!</h2><p style="margin:0 0 16px;color:#475569;font-size:15px;line-height:1.6;">Thank you for joining Career Setu AI, your personalized career guidance platform.</p><h3 style="margin:24px 0 12px;color:#1e293b;font-size:16px;">Next Steps</h3><ul style="margin:0 0 24px;padding-left:20px;color:#475569;font-size:15px;line-height:1.8;"><li>Complete your profile</li><li>Take your first career assessment</li><li>Explore the learning planner</li><li>Invite family members</li></ul>${btn(dashboardUrl, "Go to Dashboard")}`),
      };
    case "family_invitation":
      return {
        subject: "Invitation to join a Career Setu AI family dashboard",
        text: `You're invited to join a Career Setu AI family dashboard!\n\n${data.inviterName || "A family member"} has invited you to join as a ${data.role || "family member"}.\n\nAccept: ${data.inviteUrl || ""}\n\nExpires: ${data.expiresAt || "the expiration date"}`,
        html: wrap(`<h2 style="margin:0 0 16px;color:#1e293b;font-size:20px;">You're Invited!</h2><p style="margin:0 0 16px;color:#475569;font-size:15px;line-height:1.6;">${data.inviterName || "A family member"} has invited you to join their family dashboard as a ${data.role || "family member"}.</p>${btn(data.inviteUrl || "#", "Accept Invitation", "#0d9488")}<p style="margin:16px 0 0;color:#94a3b8;font-size:13px;">This invitation expires on ${data.expiresAt || "the expiration date"}.</p>`),
      };
    case "inactivity_15":
      return {
        subject: "Career Setu AI — Learning progress reminder",
        text: `Hi ${recipientName},\n\nIt's been a while since your last learning activity (last: ${data.lastActivityDate || "recently"}). Resume learning: ${data.plannerUrl || dashboardUrl}`,
        html: wrap(`<h2 style="margin:0 0 16px;color:#1e293b;font-size:20px;">Hi ${recipientName}, we miss you!</h2><p style="margin:0 0 16px;color:#475569;font-size:15px;line-height:1.6;">Your last activity was on <strong>${data.lastActivityDate || "recently"}</strong>. Consistency is key — pick up where you left off!</p>${btn(data.plannerUrl || dashboardUrl, "Resume Learning")}`),
      };
    case "inactivity_30":
    case "follow_up":
      return {
        subject: "Career Setu AI — Student progress follow-up required",
        text: `Follow-up required: ${data.studentName || recipientName} has been inactive for 30 days.\n\nLast activity: ${data.lastActivityDate || "over 30 days ago"}\n\nView dashboard: ${dashboardUrl}`,
        html: wrap(`<h2 style="margin:0 0 16px;color:#1e293b;font-size:20px;">Follow-up Needed: ${data.studentName || recipientName}</h2><p style="margin:0 0 16px;color:#475569;font-size:15px;line-height:1.6;">It has been 30 days since ${data.studentName || "the student"} last engaged. Last activity: <strong>${data.lastActivityDate || "over 30 days ago"}</strong>.</p><ul style="margin:0 0 24px;padding-left:20px;color:#475569;font-size:15px;line-height:1.8;"><li>Reach out to understand challenges</li><li>Review the learning plan</li><li>Consider a mentoring session</li></ul>${btn(dashboardUrl, "View Dashboard")}`),
      };
    case "monthly_report":
      return {
        subject: "Your monthly Career Setu AI progress report",
        text: `Monthly Progress Report — ${data.reportPeriod || "this month"}\n\nAssessments: ${data.assessmentsCompleted || "0"}\nActivities: ${data.activitiesCompleted || "0"}\nSkill: ${data.skillProgress || "In progress"}\n\nView: ${dashboardUrl}`,
        html: wrap(`<h2 style="margin:0 0 16px;color:#1e293b;font-size:20px;">Monthly Progress Report</h2><p style="margin:0 0 16px;color:#475569;font-size:15px;">Period: <strong>${data.reportPeriod || "this month"}</strong></p><table width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 24px;"><tr><td style="padding:12px 16px;background:#f1f5f9;border-radius:8px 8px 0 0;color:#1e293b;font-size:14px;font-weight:600;border-bottom:1px solid #e2e8f0;">Assessments</td><td style="padding:12px 16px;background:#f1f5f9;border-radius:8px 8px 0 0;color:#2563eb;font-size:14px;font-weight:700;text-align:right;border-bottom:1px solid #e2e8f0;">${data.assessmentsCompleted || "0"}</td></tr><tr><td style="padding:12px 16px;background:#f8fafc;color:#1e293b;font-size:14px;font-weight:600;border-bottom:1px solid #e2e8f0;">Activities</td><td style="padding:12px 16px;background:#f8fafc;color:#2563eb;font-size:14px;font-weight:700;text-align:right;border-bottom:1px solid #e2e8f0;">${data.activitiesCompleted || "0"}</td></tr><tr><td style="padding:12px 16px;background:#f1f5f9;border-radius:0 0 8px 8px;color:#1e293b;font-size:14px;font-weight:600;">Skill Development</td><td style="padding:12px 16px;background:#f1f5f9;border-radius:0 0 8px 8px;color:#2563eb;font-size:14px;font-weight:700;text-align:right;">${data.skillProgress || "In progress"}</td></tr></table>${data.recommendedNextSteps ? `<p style="margin:0 0 24px;color:#475569;font-size:15px;"><strong>Next Steps:</strong> ${data.recommendedNextSteps}</p>` : ""}${btn(dashboardUrl, "View Full Report")}`),
      };
    case "additional_support":
      return {
        subject: "Career Setu AI — Additional learning support available",
        text: `Hi ${recipientName},\n\nBased on recent assessments, ${data.studentName || "the student"} may benefit from additional support.\n\nView dashboard: ${dashboardUrl}`,
        html: wrap(`<h2 style="margin:0 0 16px;color:#1e293b;font-size:20px;">Additional Support Available</h2><p style="margin:0 0 16px;color:#475569;font-size:15px;line-height:1.6;">Based on recent assessment results, ${data.studentName || "the student"} may benefit from additional learning support.</p><ul style="margin:0 0 24px;padding-left:20px;color:#475569;font-size:15px;line-height:1.8;"><li>Schedule a mentoring session</li><li>Review assessment results together</li><li>Adjust the learning plan</li><li>Set smaller achievable goals</li></ul>${btn(dashboardUrl, "View Dashboard", "#0d9488")}`),
      };
    case "test":
      return {
        subject: "Career Setu AI — Test Email",
        text: `Career Setu AI — Test Email\n\nHello ${recipientName}, this is a test email. If you received this, your Gmail API integration is working correctly.\n\nSent at: ${new Date().toISOString()}`,
        html: wrap(`<h2 style="margin:0 0 16px;color:#1e293b;font-size:20px;">Test Email Successful</h2><p style="margin:0 0 16px;color:#475569;font-size:15px;line-height:1.6;">Hello ${recipientName}, this is a test email from Career Setu AI. If you received this, your Gmail API integration is working correctly.</p><p style="margin:0;color:#475569;font-size:15px;">Sent at: ${new Date().toISOString()}</p>`),
      };
    default:
      throw new Error(`Unknown email type: ${type}`);
  }
}

// ---- Gmail API token refresh ----

async function getAccessToken(): Promise<string> {
  const clientId = Deno.env.get("GOOGLE_CLIENT_ID");
  const clientSecret = Deno.env.get("GOOGLE_CLIENT_SECRET");
  const refreshToken = Deno.env.get("GOOGLE_REFRESH_TOKEN");

  if (!clientId || !clientSecret || !refreshToken) {
    throw new Error("Gmail API credentials not configured. Set GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, and GOOGLE_REFRESH_TOKEN as edge function secrets.");
  }

  const response = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: clientId,
      client_secret: clientSecret,
      refresh_token: refreshToken,
      grant_type: "refresh_token",
    }),
  });

  if (!response.ok) {
    const errorBody = await response.text();
    throw new Error(`Failed to refresh access token: ${response.status} ${errorBody}`);
  }

  const data = await response.json();
  return data.access_token as string;
}

// ---- Gmail API send ----

async function sendGmailEmail(
  accessToken: string,
  senderEmail: string,
  recipientEmail: string,
  subject: string,
  textBody: string,
  htmlBody: string
): Promise<string> {
  const boundary = "boundary_" + Math.random().toString(36).slice(2);

  const rawEmail = [
    `From: Career Setu AI <${senderEmail}>`,
    `To: ${recipientEmail}`,
    `Subject: ${subject}`,
    `MIME-Version: 1.0`,
    `Content-Type: multipart/alternative; boundary="${boundary}"`,
    ``,
    `--${boundary}`,
    `Content-Type: text/plain; charset="UTF-8"`,
    `Content-Transfer-Encoding: base64`,
    ``,
    btoa(unescape(encodeURIComponent(textBody))),
    ``,
    `--${boundary}`,
    `Content-Type: text/html; charset="UTF-8"`,
    `Content-Transfer-Encoding: base64`,
    ``,
    btoa(unescape(encodeURIComponent(htmlBody))),
    ``,
    `--${boundary}--`,
  ].join("\r\n");

  const encodedMessage = btoa(rawEmail).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");

  const response = await fetch(
    "https://gmail.googleapis.com/gmail/v1/users/me/messages.send",
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ raw: encodedMessage }),
    }
  );

  if (!response.ok) {
    const errorBody = await response.text();
    const err = new Error(`Gmail API error: ${response.status} ${errorBody}`);
    (err as any).status = response.status;
    throw err;
  }

  const data = await response.json();
  return data.id as string;
}

// ---- Main handler ----

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const body: SendEmailRequest = await req.json();

    if (!body.recipient_email || !body.type) {
      return new Response(
        JSON.stringify({ error: "Missing required fields: type, recipient_email" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const emailContent = generateEmail(body.type, body.template_data || {});
    const senderEmail = Deno.env.get("GMAIL_SENDER_EMAIL");

    if (!senderEmail) {
      return new Response(
        JSON.stringify({ error: "GMAIL_SENDER_EMAIL not configured. Set it as an edge function secret." }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Deduplication check
    if (body.dedup_key) {
      const { data: existing } = await supabase
        .from("notification_log")
        .select("id, status")
        .eq("dedup_key", body.dedup_key)
        .in("status", ["sent", "pending", "retrying"])
        .limit(1);

      if (existing && existing.length > 0) {
        return new Response(
          JSON.stringify({ message: "Duplicate notification suppressed", dedup_key: body.dedup_key }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    // Create notification log entry
    const { data: logEntry } = await supabase
      .from("notification_log")
      .insert({
        user_id: body.recipient_user_id || null,
        recipient_email: body.recipient_email,
        notification_type: body.type,
        subject: emailContent.subject,
        status: "pending",
        dedup_key: body.dedup_key || null,
      })
      .select()
      .single();

    const logId = logEntry?.id;

    try {
      const accessToken = await getAccessToken();
      const messageId = await sendGmailEmail(
        accessToken,
        senderEmail,
        body.recipient_email,
        emailContent.subject,
        emailContent.text,
        emailContent.html
      );

      await supabase
        .from("notification_log")
        .update({
          status: "sent",
          provider_message_id: messageId,
          sent_at: new Date().toISOString(),
        })
        .eq("id", logId);

      return new Response(
        JSON.stringify({ success: true, message_id: messageId, log_id: logId }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    } catch (sendError) {
      const errorMessage = sendError instanceof Error ? sendError.message : String(sendError);
      const isRetryable = errorMessage.includes("429") || errorMessage.includes("500") || errorMessage.includes("503");

      await supabase
        .from("notification_log")
        .update({
          status: isRetryable ? "retrying" : "failed",
          error_message: errorMessage,
          retry_count: 1,
        })
        .eq("id", logId);

      return new Response(
        JSON.stringify({ error: errorMessage, retryable: isRetryable, log_id: logId }),
        { status: isRetryable ? 503 : 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
  } catch (err) {
    const errorMessage = err instanceof Error ? err.message : String(err);
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

