/*
# Fix security advisories on trigger functions

## Changes
1. Revoke EXECUTE from anon and authenticated on handle_new_user (should only be called by the trigger)
2. Set search_path on both functions to pg_catalog,public to prevent search_path injection
*/

REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM anon, authenticated;

ALTER FUNCTION public.handle_new_user() SET search_path = pg_catalog, public;
ALTER FUNCTION public.update_updated_at() SET search_path = pg_catalog, public;