/*
# Career Setu AI — Core Schema with Gmail Notification Integration

## Overview
This migration creates the full database schema for the Career Setu AI platform, including user profiles with role-based access (student, parent, mentor), family groups for parent-student linking, secure invitations, assessments, learning activities, notification preferences, and notification delivery history.

## New Tables
1. `profiles` — User profile linked to auth.users, with role (student/parent/mentor) and timezone
2. `family_groups` — Groups that link parents/guardians to students
3. `family_members` — Junction table linking users to family groups with their role in the family
4. `invitations` — Secure family-dashboard invitations with expiration and token-based acceptance
5. `assessments` — Career assessment records with scores and support-needed flag
6. `activities` — Learning activity log entries with timestamps for inactivity tracking
7. `monthly_reports` — Generated monthly progress report metadata
8. `notification_preferences` — Per-user email notification settings (opt-in/opt-out per type)
9. `notification_log` — Delivery history for every notification sent

## Security (RLS)
- All tables have RLS enabled
- Owner-scoped policies using auth.uid() for profiles, notification_preferences, notification_log
- Family-group-scoped access verified through family_members membership
- 4 separate CRUD policies per table (SELECT/INSERT/UPDATE/DELETE)

## Important Notes
1. This app has a sign-in screen — all policies scoped TO authenticated
2. Owner columns default to auth.uid() so inserts work without explicitly passing user_id
3. Family-group membership is verified via EXISTS subqueries against family_members
4. Invitation tokens are generated server-side and are opaque (not user-editable)
*/

-- ============================================================
-- TABLE CREATION (all tables first, policies after)
-- ============================================================

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  full_name text NOT NULL DEFAULT '',
  role text NOT NULL DEFAULT 'student' CHECK (role IN ('student', 'parent', 'mentor')),
  timezone text NOT NULL DEFAULT 'Asia/Kolkata',
  email_verified boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS family_groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL DEFAULT 'My Family',
  created_by uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS family_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  family_group_id uuid NOT NULL REFERENCES family_groups(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role_in_family text NOT NULL CHECK (role_in_family IN ('student', 'parent', 'mentor')),
  joined_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (family_group_id, user_id)
);

CREATE TABLE IF NOT EXISTS invitations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  family_group_id uuid NOT NULL REFERENCES family_groups(id) ON DELETE CASCADE,
  invited_email text NOT NULL,
  invited_by uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  invited_name text NOT NULL DEFAULT '',
  role_in_family text NOT NULL CHECK (role_in_family IN ('student', 'parent', 'mentor')),
  token text NOT NULL DEFAULT encode(gen_random_bytes(32), 'hex'),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'expired', 'revoked')),
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '7 days'),
  accepted_at timestamptz,
  accepted_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_invitations_token ON invitations(token);
CREATE INDEX IF NOT EXISTS idx_invitations_email ON invitations(invited_email);

CREATE TABLE IF NOT EXISTS assessments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  family_group_id uuid REFERENCES family_groups(id) ON DELETE SET NULL,
  title text NOT NULL DEFAULT 'Career Assessment',
  score integer,
  max_score integer DEFAULT 100,
  needs_additional_support boolean NOT NULL DEFAULT false,
  support_notes text NOT NULL DEFAULT '',
  completed_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_assessments_student ON assessments(student_id);
CREATE INDEX IF NOT EXISTS idx_assessments_needs_support ON assessments(needs_additional_support) WHERE needs_additional_support = true;

CREATE TABLE IF NOT EXISTS activities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  family_group_id uuid REFERENCES family_groups(id) ON DELETE SET NULL,
  activity_type text NOT NULL DEFAULT 'learning',
  description text NOT NULL DEFAULT '',
  activity_date timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_activities_student ON activities(student_id);
CREATE INDEX IF NOT EXISTS idx_activities_date ON activities(activity_date DESC);

CREATE TABLE IF NOT EXISTS monthly_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  family_group_id uuid REFERENCES family_groups(id) ON DELETE SET NULL,
  report_month date NOT NULL DEFAULT date_trunc('month', now())::date,
  assessments_completed integer NOT NULL DEFAULT 0,
  activities_completed integer NOT NULL DEFAULT 0,
  skill_progress text NOT NULL DEFAULT '',
  career_progress text NOT NULL DEFAULT '',
  outstanding_tasks text NOT NULL DEFAULT '',
  recommended_next_steps text NOT NULL DEFAULT '',
  generated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (student_id, report_month)
);

CREATE INDEX IF NOT EXISTS idx_monthly_reports_student ON monthly_reports(student_id);

CREATE TABLE IF NOT EXISTS notification_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  email_enabled boolean NOT NULL DEFAULT true,
  monthly_report_enabled boolean NOT NULL DEFAULT true,
  learning_reminder_enabled boolean NOT NULL DEFAULT true,
  parent_notifications_enabled boolean NOT NULL DEFAULT true,
  mentor_notifications_enabled boolean NOT NULL DEFAULT true,
  support_alerts_enabled boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id)
);

CREATE TABLE IF NOT EXISTS notification_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  recipient_email text NOT NULL,
  notification_type text NOT NULL CHECK (notification_type IN (
    'welcome', 'family_invitation', 'inactivity_15', 'inactivity_30',
    'monthly_report', 'additional_support', 'follow_up', 'test'
  )),
  subject text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'sent', 'failed', 'retrying')),
  provider_message_id text,
  error_message text,
  retry_count integer NOT NULL DEFAULT 0,
  dedup_key text,
  sent_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_notification_log_user ON notification_log(user_id);
CREATE INDEX IF NOT EXISTS idx_notification_log_dedup ON notification_log(dedup_key);
CREATE INDEX IF NOT EXISTS idx_notification_log_status ON notification_log(status);
CREATE INDEX IF NOT EXISTS idx_notification_log_type_date ON notification_log(notification_type, created_at DESC);

-- ============================================================
-- ENABLE RLS ON ALL TABLES
-- ============================================================
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE family_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE family_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE invitations ENABLE ROW LEVEL SECURITY;
ALTER TABLE assessments ENABLE ROW LEVEL SECURITY;
ALTER TABLE activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE monthly_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE notification_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE notification_log ENABLE ROW LEVEL SECURITY;

-- ============================================================
-- POLICIES: PROFILES
-- ============================================================
DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "delete_own_profile" ON profiles;
CREATE POLICY "delete_own_profile" ON profiles FOR DELETE
  TO authenticated USING (auth.uid() = id);

-- ============================================================
-- POLICIES: FAMILY GROUPS
-- ============================================================
DROP POLICY IF EXISTS "select_family_groups" ON family_groups;
CREATE POLICY "select_family_groups" ON family_groups FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM family_members fm WHERE fm.family_group_id = family_groups.id AND fm.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "insert_family_groups" ON family_groups;
CREATE POLICY "insert_family_groups" ON family_groups FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = created_by);

DROP POLICY IF EXISTS "update_family_groups" ON family_groups;
CREATE POLICY "update_family_groups" ON family_groups FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM family_members fm WHERE fm.family_group_id = family_groups.id AND fm.user_id = auth.uid())
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM family_members fm WHERE fm.family_group_id = family_groups.id AND fm.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "delete_family_groups" ON family_groups;
CREATE POLICY "delete_family_groups" ON family_groups FOR DELETE
  TO authenticated USING (auth.uid() = created_by);

-- ============================================================
-- POLICIES: FAMILY MEMBERS
-- ============================================================
DROP POLICY IF EXISTS "select_family_members" ON family_members;
CREATE POLICY "select_family_members" ON family_members FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM family_members fm2 WHERE fm2.family_group_id = family_members.family_group_id AND fm2.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "insert_family_members" ON family_members;
CREATE POLICY "insert_family_members" ON family_members FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM family_groups fg WHERE fg.id = family_members.family_group_id AND fg.created_by = auth.uid())
  );

DROP POLICY IF EXISTS "update_family_members" ON family_members;
CREATE POLICY "update_family_members" ON family_members FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM family_groups fg WHERE fg.id = family_members.family_group_id AND fg.created_by = auth.uid())
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM family_groups fg WHERE fg.id = family_members.family_group_id AND fg.created_by = auth.uid())
  );

DROP POLICY IF EXISTS "delete_family_members" ON family_members;
CREATE POLICY "delete_family_members" ON family_members FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM family_groups fg WHERE fg.id = family_members.family_group_id AND fg.created_by = auth.uid())
  );

-- ============================================================
-- POLICIES: INVITATIONS
-- ============================================================
DROP POLICY IF EXISTS "select_invitations" ON invitations;
CREATE POLICY "select_invitations" ON invitations FOR SELECT
  TO authenticated USING (
    auth.uid() = invited_by
    OR EXISTS (SELECT 1 FROM family_members fm WHERE fm.family_group_id = invitations.family_group_id AND fm.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "insert_invitations" ON invitations;
CREATE POLICY "insert_invitations" ON invitations FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = invited_by);

DROP POLICY IF EXISTS "update_invitations" ON invitations;
CREATE POLICY "update_invitations" ON invitations FOR UPDATE
  TO authenticated USING (auth.uid() = invited_by) WITH CHECK (auth.uid() = invited_by);

DROP POLICY IF EXISTS "delete_invitations" ON invitations;
CREATE POLICY "delete_invitations" ON invitations FOR DELETE
  TO authenticated USING (auth.uid() = invited_by);

-- ============================================================
-- POLICIES: ASSESSMENTS
-- ============================================================
DROP POLICY IF EXISTS "select_assessments" ON assessments;
CREATE POLICY "select_assessments" ON assessments FOR SELECT
  TO authenticated USING (
    auth.uid() = student_id
    OR EXISTS (SELECT 1 FROM family_members fm WHERE fm.family_group_id = assessments.family_group_id AND fm.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "insert_assessments" ON assessments;
CREATE POLICY "insert_assessments" ON assessments FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = student_id);

DROP POLICY IF EXISTS "update_assessments" ON assessments;
CREATE POLICY "update_assessments" ON assessments FOR UPDATE
  TO authenticated USING (auth.uid() = student_id) WITH CHECK (auth.uid() = student_id);

DROP POLICY IF EXISTS "delete_assessments" ON assessments;
CREATE POLICY "delete_assessments" ON assessments FOR DELETE
  TO authenticated USING (auth.uid() = student_id);

-- ============================================================
-- POLICIES: ACTIVITIES
-- ============================================================
DROP POLICY IF EXISTS "select_activities" ON activities;
CREATE POLICY "select_activities" ON activities FOR SELECT
  TO authenticated USING (
    auth.uid() = student_id
    OR EXISTS (SELECT 1 FROM family_members fm WHERE fm.family_group_id = activities.family_group_id AND fm.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "insert_activities" ON activities;
CREATE POLICY "insert_activities" ON activities FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = student_id);

DROP POLICY IF EXISTS "update_activities" ON activities;
CREATE POLICY "update_activities" ON activities FOR UPDATE
  TO authenticated USING (auth.uid() = student_id) WITH CHECK (auth.uid() = student_id);

DROP POLICY IF EXISTS "delete_activities" ON activities;
CREATE POLICY "delete_activities" ON activities FOR DELETE
  TO authenticated USING (auth.uid() = student_id);

-- ============================================================
-- POLICIES: MONTHLY REPORTS
-- ============================================================
DROP POLICY IF EXISTS "select_monthly_reports" ON monthly_reports;
CREATE POLICY "select_monthly_reports" ON monthly_reports FOR SELECT
  TO authenticated USING (
    auth.uid() = student_id
    OR EXISTS (SELECT 1 FROM family_members fm WHERE fm.family_group_id = monthly_reports.family_group_id AND fm.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "insert_monthly_reports" ON monthly_reports;
CREATE POLICY "insert_monthly_reports" ON monthly_reports FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = student_id);

DROP POLICY IF EXISTS "update_monthly_reports" ON monthly_reports;
CREATE POLICY "update_monthly_reports" ON monthly_reports FOR UPDATE
  TO authenticated USING (auth.uid() = student_id) WITH CHECK (auth.uid() = student_id);

DROP POLICY IF EXISTS "delete_monthly_reports" ON monthly_reports;
CREATE POLICY "delete_monthly_reports" ON monthly_reports FOR DELETE
  TO authenticated USING (auth.uid() = student_id);

-- ============================================================
-- POLICIES: NOTIFICATION PREFERENCES
-- ============================================================
DROP POLICY IF EXISTS "select_own_preferences" ON notification_preferences;
CREATE POLICY "select_own_preferences" ON notification_preferences FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_preferences" ON notification_preferences;
CREATE POLICY "insert_own_preferences" ON notification_preferences FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_preferences" ON notification_preferences;
CREATE POLICY "update_own_preferences" ON notification_preferences FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_preferences" ON notification_preferences;
CREATE POLICY "delete_own_preferences" ON notification_preferences FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============================================================
-- POLICIES: NOTIFICATION LOG
-- ============================================================
DROP POLICY IF EXISTS "select_own_notifications" ON notification_log;
CREATE POLICY "select_own_notifications" ON notification_log FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_notifications" ON notification_log;
CREATE POLICY "insert_own_notifications" ON notification_log FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_notifications" ON notification_log;
CREATE POLICY "update_own_notifications" ON notification_log FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_notifications" ON notification_log;
CREATE POLICY "delete_own_notifications" ON notification_log FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============================================================
-- TRIGGERS & FUNCTIONS
-- ============================================================
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_profiles_updated_at ON profiles;
CREATE TRIGGER trg_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS trg_preferences_updated_at ON notification_preferences;
CREATE TRIGGER trg_preferences_updated_at
  BEFORE UPDATE ON notification_preferences
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO profiles (id, email, full_name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'full_name', ''));
  INSERT INTO notification_preferences (user_id) VALUES (NEW.id);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();