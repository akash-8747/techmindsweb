/*
# Enable pg_cron and schedule the progress-monitor edge function

## Overview
This migration enables the pg_cron extension and creates a scheduled job that calls the `progress-monitor` edge function every day at 9:00 AM UTC. The edge function checks student inactivity, generates monthly reports, and sends notification emails via the Gmail API.

## Changes
1. Enable the `pg_cron` extension if not already enabled
2. Create a scheduled job `career_setu_progress_monitor` that runs daily
3. The job uses `net.http_post` to call the edge function endpoint

## Security
- The cron job uses the `supabase_admin` role
- The edge function URL and anon key are referenced from the database settings

## Important Notes
1. pg_cron must be enabled in the Supabase dashboard under Database > Extensions if this migration fails
2. The edge function must be deployed before this job will succeed
3. The schedule is daily at 09:00 UTC — adjust as needed for different timezones
*/

CREATE EXTENSION IF NOT EXISTS pg_cron;

-- Grant permissions for pg_cron
DO $$
BEGIN
  -- Schedule the progress monitor to run daily at 9:00 AM UTC
  PERFORM cron.schedule(
    'career_setu_progress_monitor',
    '0 9 * * *',
    $CRON$
      SELECT net.http_post(
        url := current_setting('app.functions_url', true) || '/progress-monitor',
        headers := jsonb_build_object(
          'Content-Type', 'application/json',
          'Authorization', 'Bearer ' || current_setting('app.service_role_key', true)
        ),
        body := jsonb_build_object()
      );
    $CRON$
  );
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'Could not schedule cron job: %', SQLERRM;
END
$$;