# Gmail API Integration — Career Setu AI

## Overview

Career Setu AI uses the Gmail API to send automated email notifications to students, parents/guardians, and mentors. Notifications include welcome emails, family invitations, inactivity reminders (15-day and 30-day), monthly progress reports, and additional-support alerts.

The integration uses:
- **Supabase Edge Functions** for server-side email sending
- **OAuth 2.0** for Gmail authentication
- **pg_cron** for scheduled progress monitoring
- **Row Level Security** for database access control

---

## Architecture

```
Frontend (React) → Supabase Edge Function (send-email) → Gmail API
                   Supabase Edge Function (progress-monitor) → send-email → Gmail API
                   pg_cron → progress-monitor (daily at 9:00 AM UTC)
```

### Files Created

| File | Purpose |
|------|---------|
| `src/lib/supabase.ts` | Supabase client singleton |
| `src/lib/emailTemplates.ts` | Email template definitions (frontend reference) |
| `src/types/database.ts` | TypeScript types for all database tables |
| `src/context/AuthContext.tsx` | Authentication context with sign-in/sign-up |
| `src/components/AuthScreen.tsx` | Sign-in / sign-up screen |
| `src/components/AppLayout.tsx` | Sidebar navigation and layout shell |
| `src/views/Dashboard.tsx` | Student dashboard with stats and activity overview |
| `src/views/FamilyView.tsx` | Family management — invitations, members |
| `src/views/AssessmentsView.tsx` | Assessment tracking with support flagging |
| `src/views/ActivitiesView.tsx` | Learning activity logging |
| `src/views/ReportsView.tsx` | Monthly report generation from real data |
| `src/views/NotificationSettingsView.tsx` | Email notification preferences + test email |
| `src/views/NotificationHistoryView.tsx` | Notification delivery history |
| `supabase/functions/send-email/index.ts` | Gmail API email sending edge function |
| `supabase/functions/progress-monitor/index.ts` | Scheduled inactivity monitoring + report generation |
| `supabase/config.toml` | Edge function configuration |

### Database Tables

| Table | Purpose |
|-------|---------|
| `profiles` | User profiles with role (student/parent/mentor) |
| `family_groups` | Family groupings linking parents to students |
| `family_members` | Junction: users ↔ family groups with family role |
| `invitations` | Secure token-based family invitations with expiration |
| `assessments` | Career assessment records with support-needed flag |
| `activities` | Learning activity log for inactivity tracking |
| `monthly_reports` | Generated monthly progress report data |
| `notification_preferences` | Per-user email notification opt-in/opt-out |
| `notification_log` | Delivery history with status, message ID, errors |

---

## 1. Configure Google Cloud and Enable Gmail API

1. Go to the [Google Cloud Console](https://console.cloud.google.com/).
2. Create a new project (or select an existing one).
3. Navigate to **APIs & Services → Library**.
4. Search for **Gmail API** and click **Enable**.
5. Navigate to **APIs & Services → OAuth consent screen**.
6. Configure the consent screen:
   - User type: **Internal** (for Google Workspace) or **External** (for personal Gmail)
   - App name: `Career Setu AI`
   - Support email: your sender email
   - Add the scope: `https://www.googleapis.com/auth/gmail.send`
   - If using External, add your test user(s)

---

## 2. Create OAuth Credentials

1. Navigate to **APIs & Services → Credentials**.
2. Click **Create Credentials → OAuth client ID**.
3. Select **Web application**.
4. Name: `Career Setu AI Email Service`
5. Add an authorized redirect URI: `https://developers.google.com/oauthplayground`
6. Click **Create**.
7. Note the **Client ID** and **Client Secret** — you will need these in Step 3.

---

## 3. Authorize the Sender Account and Get a Refresh Token

Use the [OAuth 2.0 Playground](https://developers.google.com/oauthplayground/) to obtain a refresh token:

1. Go to [OAuth Playground](https://developers.google.com/oauthplayground/).
2. Click the **gear icon** (OAuth 2.0 configuration) in the top right.
3. Check **Use your own OAuth credentials**.
4. Paste your **Client ID** and **Client Secret** from Step 2.
5. Close the settings panel.
6. In the left panel, find the **Gmail API v1** section and select the scope:
   `https://www.googleapis.com/auth/gmail.send`
7. Click **Authorize APIs** and sign in with the Gmail account that will send emails.
8. Grant permission.
9. Click **Exchange authorization code for tokens**.
10. Copy the **Refresh Token** — this token does not expire unless revoked.

> **Important:** Store the refresh token securely. It grants the ability to send emails on behalf of the authorized account.

---

## 4. Add Secrets Securely

All Gmail credentials must be stored as **Supabase Edge Function secrets** — never in frontend code or `.env` files.

The following secrets are required:

| Secret Name | Description |
|-------------|-------------|
| `GOOGLE_CLIENT_ID` | OAuth client ID from Google Cloud Console |
| `GOOGLE_CLIENT_SECRET` | OAuth client secret from Google Cloud Console |
| `GOOGLE_REFRESH_TOKEN` | Refresh token from OAuth Playground |
| `GMAIL_SENDER_EMAIL` | The Gmail address authorized to send emails (e.g., `notifications@gmail.com`) |
| `SITE_URL` | Your site URL for dashboard links in emails (e.g., `https://career-setu-ai-platf-625l.bolt.host`) |

### How to set secrets

Set these in the Supabase dashboard:
1. Go to your Supabase project dashboard.
2. Navigate to **Edge Functions → Secrets**.
3. Add each secret with its value.

Or via the Supabase CLI (if available):
```bash
supabase secrets set GOOGLE_CLIENT_ID=your-client-id
supabase secrets set GOOGLE_CLIENT_SECRET=your-client-secret
supabase secrets set GOOGLE_REFRESH_TOKEN=your-refresh-token
supabase secrets set GMAIL_SENDER_EMAIL=your-sender@gmail.com
supabase secrets set SITE_URL=https://career-setu-ai-platf-625l.bolt.host
```

> **Never** add these to `.env`, `.env.example`, or any file in the frontend. The `.env.example` file contains only placeholder comments for documentation.

---

## 5. Deploy the Backend and Scheduled Jobs

### Edge Functions

The edge functions are deployed automatically when you call the Supabase deploy tool. If you need to redeploy:

1. Ensure the source files are at:
   - `supabase/functions/send-email/index.ts`
   - `supabase/functions/progress-monitor/index.ts`
2. Ensure `supabase/config.toml` has entries for both functions.
3. The deploy tool deploys all changed functions in one call.

### Scheduled Job (pg_cron)

A pg_cron job `career_setu_progress_monitor` is created by migration `002_enable_cron_schedule`. It runs **daily at 9:00 AM UTC**.

To verify the job is active:
```sql
SELECT jobname, schedule, active FROM cron.job WHERE jobname = 'career_setu_progress_monitor';
```

To reschedule (e.g., run at 6:00 AM UTC):
```sql
SELECT cron.unschedule('career_setu_progress_monitor');
SELECT cron.schedule('career_setu_progress_monitor', '0 6 * * *',
  'SELECT net.http_post(...)');
```

To manually trigger the progress monitor:
```bash
curl -X POST "https://your-project.supabase.co/functions/v1/progress-monitor" \
  -H "Authorization: Bearer YOUR_SERVICE_ROLE_KEY" \
  -H "Content-Type: application/json" \
  -d '{}'
```

---

## 6. Send a Test Email

### From the UI

1. Sign in to Career Setu AI.
2. Navigate to **Settings** (the gear icon in the sidebar).
3. Scroll to the **Send Test Email** section.
4. Enter a recipient email (or leave blank to use your account email).
5. Click **Send Test**.
6. Check the status message — it will show success with the Gmail message ID, or an error if credentials are missing.

### Via curl

```bash
curl -X POST "https://your-project.supabase.co/functions/v1/send-email" \
  -H "Authorization: Bearer YOUR_ANON_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "type": "test",
    "recipient_email": "test-recipient@example.com",
    "template_data": {
      "recipientName": "Test User"
    }
  }'
```

### Expected Responses

**Success:**
```json
{ "success": true, "message_id": "msg-id-xxx", "log_id": "uuid" }
```

**Missing credentials:**
```json
{ "error": "Gmail API credentials not configured. Set GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, and GOOGLE_REFRESH_TOKEN as edge function secrets." }
```

**Duplicate suppressed:**
```json
{ "message": "Duplicate notification suppressed", "dedup_key": "monthly_report:uuid:2026-10" }
```

---

## 7. Notification Types

| Type | Trigger | Template Subject |
|------|---------|-----------------|
| `welcome` | New user registration | Welcome to Career Setu AI |
| `family_invitation` | Family member invited | Invitation to join a Career Setu AI family dashboard |
| `inactivity_15` | 15 days without activity | Career Setu AI — Learning progress reminder |
| `inactivity_30` | 30 days without activity | Career Setu AI — Student progress follow-up required |
| `monthly_report` | Monthly auto-generation | Your monthly Career Setu AI progress report |
| `additional_support` | Assessment flagged | Career Setu AI — Additional learning support available |
| `follow_up` | 30-day inactivity to parent/mentor | Career Setu AI — Student progress follow-up required |
| `test` | Manual test | Career Setu AI — Test Email |

---

## 8. Notification Preferences

Each user can control their notification preferences from the **Settings** page:

- **Email Notifications** (master switch)
- **Monthly Progress Reports**
- **Learning Reminders** (15/30 day inactivity)
- **Parent/Guardian Notifications** (parents receive updates)
- **Mentor Notifications** (mentors receive updates)
- **Additional Support Alerts**

The progress-monitor edge function checks these preferences before sending any notification.

---

## 9. Security Notes

- All Gmail credentials are stored as edge function secrets, never exposed to the frontend.
- The `send-email` function uses `verify_jwt = false` so it can be called from the frontend with the anon key, but it validates the request body structure and uses deduplication keys to prevent abuse.
- The `progress-monitor` function should be called with the service role key (via pg_cron or admin).
- Row Level Security is enabled on all tables with owner-scoped and family-group-scoped policies.
- Notification logs are only visible to the user they belong to.
- Invitation tokens are 32-byte random hex strings and expire after 7 days.

---

## 10. External Configuration Steps Still Required

The following steps must be completed before emails can be sent:

1. **Enable the Gmail API** in your Google Cloud Console project.
2. **Create OAuth 2.0 credentials** (client ID and secret).
3. **Authorize the sender Gmail account** and obtain a refresh token.
4. **Set the following secrets** in your Supabase project's Edge Function secrets:
   - `GOOGLE_CLIENT_ID`
   - `GOOGLE_CLIENT_SECRET`
   - `GOOGLE_REFRESH_TOKEN`
   - `GMAIL_SENDER_EMAIL`
   - `SITE_URL`
5. **Verify the pg_cron job** is active (see Section 5).
6. **Send a test email** (see Section 6) to confirm the integration works end-to-end.

Until these steps are completed, the email service will return an error indicating missing credentials. No emails will be sent.
